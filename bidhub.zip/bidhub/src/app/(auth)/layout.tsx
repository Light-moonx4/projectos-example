import type { ReactNode } from "react";

export default function AuthLayout({ children }: { children: ReactNode }) {
  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-100 px-4 py-10">
      <div className="w-full max-w-md">
        <p className="mb-6 text-center text-3xl font-bold text-indigo-600">BidHub</p>
        {children}
      </div>
    </main>
  );
}

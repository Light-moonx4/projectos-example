"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { StatusBadge } from "@/components/status-badge";
import { extractError } from "@/lib/client";
import { formatDate, formatMoney } from "@/lib/utils";
import type { AuctionStatus, AuctionSummaryDTO, Paginated } from "@/types";

type StatusFilter = AuctionStatus | "ALL";

const FILTERS: { value: StatusFilter; label: string }[] = [
  { value: "ALL", label: "Todas" },
  { value: "ACTIVE", label: "Activas" },
  { value: "CLOSED", label: "Cerradas" },
  { value: "DESERTED", label: "Desiertas" },
  { value: "CANCELED", label: "Canceladas" },
];

export default function AdminPage() {
  const [filter, setFilter] = useState<StatusFilter>("ALL");
  const [auctions, setAuctions] = useState<AuctionSummaryDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async (status: StatusFilter) => {
    setLoading(true);
    setError(null);
    try {
      const query = status === "ALL" ? "?pageSize=50" : `?status=${status}&pageSize=50`;
      const response = await fetch(`/api/moderation/auctions${query}`);
      if (!response.ok) throw new Error(await extractError(response));
      const data = (await response.json()) as Paginated<AuctionSummaryDTO>;
      setAuctions(data.items);
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "No se pudieron cargar las subastas.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load(filter);
  }, [filter, load]);

  async function handleCancel(id: string) {
    const reason = window.prompt("Motivo de la cancelación (mínimo 10 caracteres):");
    if (reason === null) return;
    setError(null);
    try {
      const response = await fetch(`/api/moderation/auctions/${id}/cancel`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reason }),
      });
      if (!response.ok) throw new Error(await extractError(response));
      await load(filter);
    } catch (cancelError) {
      setError(cancelError instanceof Error ? cancelError.message : "No se pudo cancelar la subasta.");
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Moderación de subastas</h1>

      <div className="flex flex-wrap gap-2">
        {FILTERS.map((item) => (
          <button
            key={item.value}
            type="button"
            onClick={() => setFilter(item.value)}
            className={`rounded-full border px-3 py-1 text-sm ${filter === item.value ? "border-slate-900 bg-slate-900 text-white" : "border-slate-300 bg-white"}`}
          >
            {item.label}
          </button>
        ))}
      </div>

      {error && <p className="text-sm text-red-600">{error}</p>}
      {loading ? (
        <p className="text-slate-500">Cargando...</p>
      ) : (
        <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-slate-500">
              <tr>
                <th className="px-4 py-3">Subasta</th>
                <th className="px-4 py-3">Vendedor</th>
                <th className="px-4 py-3">Precio</th>
                <th className="px-4 py-3">Cierre</th>
                <th className="px-4 py-3">Estado</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {auctions.map((auction) => (
                <tr key={auction.id}>
                  <td className="px-4 py-3">
                    <Link href={`/auctions/${auction.id}`} className="font-medium text-indigo-600 hover:underline">
                      {auction.title}
                    </Link>
                  </td>
                  <td className="px-4 py-3">{auction.seller.name}</td>
                  <td className="px-4 py-3">{formatMoney(auction.currentPrice)}</td>
                  <td className="px-4 py-3">{formatDate(auction.closingDate)}</td>
                  <td className="px-4 py-3">
                    <StatusBadge status={auction.status} />
                  </td>
                  <td className="px-4 py-3 text-right">
                    {auction.status === "ACTIVE" && (
                      <button
                        type="button"
                        onClick={() => void handleCancel(auction.id)}
                        className="rounded-md border border-red-300 px-3 py-1 text-red-600 hover:bg-red-50"
                      >
                        Cancelar
                      </button>
                    )}
                  </td>
                </tr>
              ))}
              {auctions.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center text-slate-500">
                    No hay subastas para este filtro.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

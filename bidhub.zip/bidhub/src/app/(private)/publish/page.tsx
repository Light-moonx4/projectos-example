"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState, type FormEvent } from "react";
import { extractError } from "@/lib/client";
import type { AuctionSummaryDTO, CategoryDTO } from "@/types";

export default function PublishAuctionPage() {
  const router = useRouter();
  const [categories, setCategories] = useState<CategoryDTO[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let cancelled = false;
    async function loadCategories() {
      try {
        const response = await fetch("/api/categories");
        if (!response.ok) throw new Error(await extractError(response));
        const data = (await response.json()) as { items: CategoryDTO[] };
        if (!cancelled) setCategories(data.items);
      } catch (loadError) {
        if (!cancelled) {
          setError(loadError instanceof Error ? loadError.message : "No se pudieron cargar las categorías.");
        }
      }
    }
    void loadCategories();
    return () => {
      cancelled = true;
    };
  }, []);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setError(null);

    const form = new FormData(event.currentTarget);
    const closingRaw = String(form.get("closingDate") ?? "");
    const payload = {
      title: String(form.get("title") ?? ""),
      description: String(form.get("description") ?? ""),
      imageUrl: String(form.get("imageUrl") ?? ""),
      initialPrice: Number(form.get("initialPrice")),
      minimumIncrement: Number(form.get("minimumIncrement")),
      categoryId: String(form.get("categoryId") ?? ""),
      closingDate: closingRaw ? new Date(closingRaw).toISOString() : "",
    };

    try {
      const response = await fetch("/api/auctions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        setError(await extractError(response));
        return;
      }
      const created = (await response.json()) as AuctionSummaryDTO;
      router.push(`/auctions/${created.id}`);
    } catch {
      setError("No se pudo conectar con el servidor.");
    } finally {
      setLoading(false);
    }
  }

  const inputClass = "w-full rounded-md border border-slate-300 px-3 py-2";
  const labelClass = "mb-1 block text-sm font-medium";

  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="mb-6 text-2xl font-bold">Publicar subasta</h1>
      <form onSubmit={handleSubmit} className="space-y-4 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
        <div>
          <label htmlFor="title" className={labelClass}>Título</label>
          <input id="title" name="title" required minLength={3} maxLength={120} className={inputClass} />
        </div>
        <div>
          <label htmlFor="description" className={labelClass}>Descripción</label>
          <textarea id="description" name="description" required minLength={10} maxLength={2000} rows={5} className={inputClass} />
        </div>
        <div>
          <label htmlFor="imageUrl" className={labelClass}>URL de la imagen</label>
          <input id="imageUrl" name="imageUrl" type="url" required className={inputClass} />
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="initialPrice" className={labelClass}>Precio inicial</label>
            <input id="initialPrice" name="initialPrice" type="number" step="0.01" min="0.01" required className={inputClass} />
          </div>
          <div>
            <label htmlFor="minimumIncrement" className={labelClass}>Incremento mínimo</label>
            <input id="minimumIncrement" name="minimumIncrement" type="number" step="0.01" min="0.01" required className={inputClass} />
          </div>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="categoryId" className={labelClass}>Categoría</label>
            <select id="categoryId" name="categoryId" required defaultValue="" className={inputClass}>
              <option value="" disabled>Selecciona una categoría</option>
              {categories.map((category) => (
                <option key={category.id} value={category.id}>{category.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="closingDate" className={labelClass}>Fecha de cierre</label>
            <input id="closingDate" name="closingDate" type="datetime-local" required className={inputClass} />
          </div>
        </div>
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          className="w-full rounded-md bg-indigo-600 px-4 py-2 font-medium text-white hover:bg-indigo-700 disabled:opacity-50"
        >
          {loading ? "Publicando..." : "Publicar subasta"}
        </button>
      </form>
    </div>
  );
}

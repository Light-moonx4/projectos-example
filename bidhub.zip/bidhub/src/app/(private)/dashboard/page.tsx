"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { AuctionCard } from "@/components/auction-card";
import { extractError } from "@/lib/client";
import type { AuctionSummaryDTO, Paginated } from "@/types";

type DashboardState =
  | { status: "loading" }
  | { status: "error"; message: string }
  | { status: "ready"; mine: AuctionSummaryDTO[]; bidding: AuctionSummaryDTO[] };

export default function DashboardPage() {
  const [state, setState] = useState<DashboardState>({ status: "loading" });

  useEffect(() => {
    let cancelled = false;

    async function load() {
      try {
        const [mineResponse, biddingResponse] = await Promise.all([
          fetch("/api/auctions?scope=mine&pageSize=50"),
          fetch("/api/auctions?scope=bidding&pageSize=50"),
        ]);
        if (!mineResponse.ok) throw new Error(await extractError(mineResponse));
        if (!biddingResponse.ok) throw new Error(await extractError(biddingResponse));

        const mine = (await mineResponse.json()) as Paginated<AuctionSummaryDTO>;
        const bidding = (await biddingResponse.json()) as Paginated<AuctionSummaryDTO>;
        if (!cancelled) setState({ status: "ready", mine: mine.items, bidding: bidding.items });
      } catch (error) {
        if (!cancelled) {
          setState({
            status: "error",
            message: error instanceof Error ? error.message : "No se pudo cargar tu panel.",
          });
        }
      }
    }

    void load();
    return () => {
      cancelled = true;
    };
  }, []);

  if (state.status === "loading") return <p className="text-slate-500">Cargando tu panel...</p>;
  if (state.status === "error") return <p className="text-red-600">{state.message}</p>;

  return (
    <div className="space-y-10">
      <section>
        <div className="mb-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold">Mis subastas</h1>
          <Link href="/publish" className="rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700">
            Publicar subasta
          </Link>
        </div>
        {state.mine.length === 0 ? (
          <p className="text-sm text-slate-500">Todavía no has publicado subastas.</p>
        ) : (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {state.mine.map((auction) => (
              <AuctionCard key={auction.id} auction={auction} />
            ))}
          </div>
        )}
      </section>

      <section>
        <h2 className="mb-4 text-2xl font-bold">Subastas en las que he pujado</h2>
        {state.bidding.length === 0 ? (
          <p className="text-sm text-slate-500">Aún no has realizado pujas.</p>
        ) : (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {state.bidding.map((auction) => (
              <AuctionCard key={auction.id} auction={auction} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { AuctionStatus } from "@prisma/client";
import { BidForm } from "@/components/bid-form";
import { StatusBadge } from "@/components/status-badge";
import { auctionInclude, closeExpiredAuctions } from "@/lib/auctions";
import { prisma } from "@/lib/prisma";
import { formatDate, formatMoney, isUuid } from "@/lib/utils";

// Detalle renderizado en cada petición (SSR).
export const dynamic = "force-dynamic";

interface AuctionDetailPageProps {
  params: Promise<{ id: string }>;
}

export async function generateMetadata({ params }: AuctionDetailPageProps): Promise<Metadata> {
  const { id } = await params;
  if (!isUuid(id)) return { title: "Subasta no encontrada" };
  const auction = await prisma.auction.findUnique({ where: { id }, select: { title: true } });
  return { title: auction?.title ?? "Subasta no encontrada" };
}

export default async function AuctionDetailPage({ params }: AuctionDetailPageProps) {
  const { id } = await params;
  if (!isUuid(id)) notFound();

  await closeExpiredAuctions();

  const auction = await prisma.auction.findUnique({
    where: { id },
    include: {
      ...auctionInclude,
      bids: {
        orderBy: { amount: "desc" },
        take: 20,
        select: { id: true, amount: true, createdAt: true, bidder: { select: { id: true, name: true } } },
      },
    },
  });
  if (!auction) notFound();

  const isActive = auction.status === AuctionStatus.ACTIVE;
  const minimumAmount = (
    auction._count.bids === 0 ? auction.initialPrice : auction.currentPrice.add(auction.minimumIncrement)
  ).toFixed(2);
  const winner = auction.status === AuctionStatus.CLOSED ? auction.bids[0] : undefined;

  return (
    <div className="grid gap-8 lg:grid-cols-3">
      <div className="space-y-6 lg:col-span-2">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={auction.imageUrl} alt={auction.title} className="h-96 w-full rounded-xl object-cover" />
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <span className="text-xs font-medium uppercase tracking-wide text-indigo-600">{auction.category.name}</span>
            <StatusBadge status={auction.status} />
          </div>
          <h1 className="text-3xl font-bold">{auction.title}</h1>
          <p className="whitespace-pre-line text-slate-700">{auction.description}</p>
          <p className="text-sm text-slate-500">Vendedor: {auction.seller.name}</p>
        </div>

        <section>
          <h2 className="mb-3 text-xl font-semibold">Historial de pujas</h2>
          {auction.bids.length === 0 ? (
            <p className="text-sm text-slate-500">Aún no hay pujas.</p>
          ) : (
            <ul className="divide-y divide-slate-200 rounded-xl border border-slate-200 bg-white">
              {auction.bids.map((bid) => (
                <li key={bid.id} className="flex items-center justify-between px-4 py-3 text-sm">
                  <span>{bid.bidder.name}</span>
                  <span className="font-semibold">{formatMoney(bid.amount)}</span>
                  <span className="text-slate-500">{formatDate(bid.createdAt)}</span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      <aside className="h-fit space-y-4 rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
        <div>
          <p className="text-sm text-slate-500">Precio actual</p>
          <p className="text-3xl font-bold">{formatMoney(auction.currentPrice)}</p>
        </div>
        <dl className="space-y-1 text-sm">
          <div className="flex justify-between">
            <dt className="text-slate-500">Precio inicial</dt>
            <dd>{formatMoney(auction.initialPrice)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-slate-500">Incremento mínimo</dt>
            <dd>{formatMoney(auction.minimumIncrement)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-slate-500">Cierre</dt>
            <dd>{formatDate(auction.closingDate)}</dd>
          </div>
        </dl>

        {isActive && <BidForm auctionId={auction.id} minimumAmount={minimumAmount} />}
        {winner && (
          <p className="rounded-md bg-slate-100 p-3 text-sm">
            Ganador: <strong>{winner.bidder.name}</strong> con {formatMoney(winner.amount)}.
          </p>
        )}
        {auction.status === AuctionStatus.DESERTED && (
          <p className="rounded-md bg-amber-50 p-3 text-sm text-amber-800">Esta subasta cerró sin pujas.</p>
        )}
        {auction.status === AuctionStatus.CANCELED && (
          <p className="rounded-md bg-red-50 p-3 text-sm text-red-800">
            Subasta cancelada. Motivo: {auction.cancelReason ?? "no especificado"}.
          </p>
        )}
      </aside>
    </div>
  );
}

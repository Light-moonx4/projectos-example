import type { Metadata } from "next";
import Link from "next/link";
import { AuctionStatus, type Prisma } from "@prisma/client";
import { AuctionCard } from "@/components/auction-card";
import { auctionInclude, closeExpiredAuctions } from "@/lib/auctions";
import { prisma } from "@/lib/prisma";

export const metadata: Metadata = { title: "Catálogo de subastas" };

// Catálogo renderizado en cada petición (SSR).
export const dynamic = "force-dynamic";

interface CatalogPageProps {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}

function firstValue(value: string | string[] | undefined): string | undefined {
  if (Array.isArray(value)) return value[0];
  return value && value.trim() ? value.trim() : undefined;
}

export default async function CatalogPage({ searchParams }: CatalogPageProps) {
  const params = await searchParams;
  const category = firstValue(params.category);
  const q = firstValue(params.q);

  await closeExpiredAuctions();

  const where: Prisma.AuctionWhereInput = { status: AuctionStatus.ACTIVE };
  if (category) where.category = { slug: category };
  if (q) where.title = { contains: q, mode: "insensitive" };

  const [auctions, categories] = await Promise.all([
    prisma.auction.findMany({ where, include: auctionInclude, orderBy: { closingDate: "asc" }, take: 48 }),
    prisma.category.findMany({ orderBy: { name: "asc" }, select: { id: true, name: true, slug: true } }),
  ]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <h1 className="text-3xl font-bold">Subastas activas</h1>
        <form action="/auctions" className="flex gap-2">
          {category && <input type="hidden" name="category" value={category} />}
          <input
            name="q"
            defaultValue={q}
            placeholder="Buscar por título"
            className="w-64 rounded-md border border-slate-300 px-3 py-2 text-sm"
          />
          <button type="submit" className="rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700">
            Buscar
          </button>
        </form>
      </div>

      <div className="flex flex-wrap gap-2">
        <Link
          href="/auctions"
          className={`rounded-full border px-3 py-1 text-sm ${!category ? "border-indigo-600 bg-indigo-600 text-white" : "border-slate-300 bg-white"}`}
        >
          Todas
        </Link>
        {categories.map((item) => (
          <Link
            key={item.id}
            href={`/auctions?category=${item.slug}`}
            className={`rounded-full border px-3 py-1 text-sm ${category === item.slug ? "border-indigo-600 bg-indigo-600 text-white" : "border-slate-300 bg-white"}`}
          >
            {item.name}
          </Link>
        ))}
      </div>

      {auctions.length === 0 ? (
        <p className="rounded-xl border border-dashed border-slate-300 bg-white p-10 text-center text-slate-500">
          No hay subastas activas con esos filtros.
        </p>
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {auctions.map((auction) => (
            <AuctionCard key={auction.id} auction={auction} />
          ))}
        </div>
      )}
    </div>
  );
}

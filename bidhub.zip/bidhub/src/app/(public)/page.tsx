import Link from "next/link";

// Home generada estáticamente en build (SSG): no consulta la base de datos.
export const dynamic = "force-static";

const highlights = [
  { title: "Pujas en tiempo real", text: "Cada puja se valida contra el precio actual y el incremento mínimo." },
  { title: "Subastas moderadas", text: "Un equipo de moderación revisa y cancela publicaciones sospechosas." },
  { title: "Categorías para coleccionistas", text: "Relojes, cartas coleccionables, vinilos y mucho más." },
];

export default function HomePage() {
  return (
    <div className="space-y-12">
      <section className="rounded-2xl bg-indigo-600 px-6 py-16 text-center text-white">
        <h1 className="mb-4 text-4xl font-bold">Encuentra piezas únicas y puja por ellas</h1>
        <p className="mx-auto mb-8 max-w-xl text-indigo-100">
          BidHub conecta a coleccionistas y vendedores en subastas transparentes y seguras.
        </p>
        <div className="flex justify-center gap-3">
          <Link href="/auctions" className="rounded-md bg-white px-5 py-2.5 font-medium text-indigo-700 hover:bg-indigo-50">
            Ver subastas
          </Link>
          <Link href="/register" className="rounded-md border border-white px-5 py-2.5 font-medium hover:bg-indigo-500">
            Crear cuenta
          </Link>
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-3">
        {highlights.map((item) => (
          <article key={item.title} className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <h2 className="mb-2 font-semibold">{item.title}</h2>
            <p className="text-sm text-slate-600">{item.text}</p>
          </article>
        ))}
      </section>
    </div>
  );
}

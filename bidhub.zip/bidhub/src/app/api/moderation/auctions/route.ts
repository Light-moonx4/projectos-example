import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { requireAdmin } from "@/lib/auth";
import { auctionInclude, closeExpiredAuctions } from "@/lib/auctions";
import { handleError } from "@/lib/http";
import { prisma } from "@/lib/prisma";
import { listAuctionsQuerySchema } from "@/lib/validators";

export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    await requireAdmin();
    const query = listAuctionsQuerySchema.parse(Object.fromEntries(request.nextUrl.searchParams));
    await closeExpiredAuctions();

    const where: Prisma.AuctionWhereInput = query.status ? { status: query.status } : {};
    const [items, total] = await prisma.$transaction([
      prisma.auction.findMany({
        where,
        include: auctionInclude,
        orderBy: { createdAt: "desc" },
        skip: (query.page - 1) * query.pageSize,
        take: query.pageSize,
      }),
      prisma.auction.count({ where }),
    ]);

    return NextResponse.json({ items, total, page: query.page, pageSize: query.pageSize });
  } catch (error) {
    return handleError(error);
  }
}

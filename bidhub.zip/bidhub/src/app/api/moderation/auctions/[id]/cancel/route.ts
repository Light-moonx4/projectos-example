import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { AuctionStatus } from "@prisma/client";
import { requireAdmin } from "@/lib/auth";
import { handleError, HttpError, readJson } from "@/lib/http";
import { prisma } from "@/lib/prisma";
import { isUuid } from "@/lib/utils";
import { cancelAuctionSchema } from "@/lib/validators";

interface RouteContext {
  params: Promise<{ id: string }>;
}

export async function POST(request: NextRequest, context: RouteContext): Promise<NextResponse> {
  try {
    await requireAdmin();
    const { id } = await context.params;
    if (!isUuid(id)) throw new HttpError(404, "Subasta no encontrada.");

    const { reason } = cancelAuctionSchema.parse(await readJson(request));

    const auction = await prisma.auction.findUnique({ where: { id }, select: { status: true } });
    if (!auction) throw new HttpError(404, "Subasta no encontrada.");

    const result = await prisma.auction.updateMany({
      where: { id, status: AuctionStatus.ACTIVE },
      data: { status: AuctionStatus.CANCELED, cancelReason: reason },
    });
    if (result.count === 0) {
      throw new HttpError(409, "Solo se pueden cancelar subastas activas.");
    }

    return NextResponse.json({ ok: true, id, status: AuctionStatus.CANCELED });
  } catch (error) {
    return handleError(error);
  }
}

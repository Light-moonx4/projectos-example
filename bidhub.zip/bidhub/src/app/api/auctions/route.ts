import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { AuctionStatus, Prisma } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { auctionInclude, closeExpiredAuctions } from "@/lib/auctions";
import { handleError, HttpError, readJson } from "@/lib/http";
import { prisma } from "@/lib/prisma";
import { createAuctionSchema, listAuctionsQuerySchema } from "@/lib/validators";

export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    const query = listAuctionsQuerySchema.parse(Object.fromEntries(request.nextUrl.searchParams));
    await closeExpiredAuctions();

    const where: Prisma.AuctionWhereInput = {};

    if (query.scope === "all") {
      where.status = query.status ?? AuctionStatus.ACTIVE;
    } else {
      const session = await requireAuth();
      if (query.status) where.status = query.status;
      if (query.scope === "mine") where.sellerId = session.userId;
      if (query.scope === "bidding") where.bids = { some: { bidderId: session.userId } };
    }

    if (query.category) where.category = { slug: query.category };
    if (query.q) where.title = { contains: query.q, mode: "insensitive" };

    const [items, total] = await prisma.$transaction([
      prisma.auction.findMany({
        where,
        include: auctionInclude,
        orderBy: { createdAt: "desc" },
        skip: (query.page - 1) * query.pageSize,
        take: query.pageSize,
      }),
      prisma.auction.count({ where }),
    ]);

    return NextResponse.json({ items, total, page: query.page, pageSize: query.pageSize });
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const session = await requireAuth();
    const input = createAuctionSchema.parse(await readJson(request));

    const category = await prisma.category.findUnique({ where: { id: input.categoryId }, select: { id: true } });
    if (!category) throw new HttpError(404, "La categoría seleccionada no existe.");

    const initialPrice = new Prisma.Decimal(input.initialPrice.toFixed(2));
    const auction = await prisma.auction.create({
      data: {
        title: input.title,
        description: input.description,
        imageUrl: input.imageUrl,
        initialPrice,
        currentPrice: initialPrice,
        minimumIncrement: new Prisma.Decimal(input.minimumIncrement.toFixed(2)),
        closingDate: input.closingDate,
        status: AuctionStatus.ACTIVE,
        sellerId: session.userId,
        categoryId: input.categoryId,
      },
      include: auctionInclude,
    });

    return NextResponse.json(auction, { status: 201 });
  } catch (error) {
    return handleError(error);
  }
}

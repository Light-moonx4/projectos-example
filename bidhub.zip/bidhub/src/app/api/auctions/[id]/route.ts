import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { auctionInclude, closeExpiredAuctions } from "@/lib/auctions";
import { handleError, HttpError } from "@/lib/http";
import { prisma } from "@/lib/prisma";
import { isUuid } from "@/lib/utils";

interface RouteContext {
  params: Promise<{ id: string }>;
}

export async function GET(_request: NextRequest, context: RouteContext): Promise<NextResponse> {
  try {
    const { id } = await context.params;
    if (!isUuid(id)) throw new HttpError(404, "Subasta no encontrada.");

    await closeExpiredAuctions();
    const auction = await prisma.auction.findUnique({
      where: { id },
      include: {
        ...auctionInclude,
        bids: {
          orderBy: { amount: "desc" },
          take: 20,
          select: { id: true, amount: true, createdAt: true, bidder: { select: { id: true, name: true } } },
        },
      },
    });
    if (!auction) throw new HttpError(404, "Subasta no encontrada.");

    return NextResponse.json(auction);
  } catch (error) {
    return handleError(error);
  }
}

import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { AuctionStatus, Prisma } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { closeExpiredAuctions } from "@/lib/auctions";
import { handleError, HttpError, readJson } from "@/lib/http";
import { prisma } from "@/lib/prisma";
import { isUuid } from "@/lib/utils";
import { bidSchema } from "@/lib/validators";

interface RouteContext {
  params: Promise<{ id: string }>;
}

export async function POST(request: NextRequest, context: RouteContext): Promise<NextResponse> {
  try {
    const session = await requireAuth();
    const { id } = await context.params;
    if (!isUuid(id)) throw new HttpError(404, "Subasta no encontrada.");

    const { amount } = bidSchema.parse(await readJson(request));
    const bidAmount = new Prisma.Decimal(amount.toFixed(2));

    await closeExpiredAuctions();

    const bid = await prisma.$transaction(async (tx) => {
      const auction = await tx.auction.findUnique({
        where: { id },
        include: { _count: { select: { bids: true } } },
      });
      if (!auction) throw new HttpError(404, "Subasta no encontrada.");
      if (auction.sellerId === session.userId) {
        throw new HttpError(403, "No puedes pujar en tu propia subasta.");
      }
      if (auction.status !== AuctionStatus.ACTIVE || auction.closingDate <= new Date()) {
        throw new HttpError(409, "La subasta ya no está activa.");
      }

      const minimum =
        auction._count.bids === 0 ? auction.initialPrice : auction.currentPrice.add(auction.minimumIncrement);
      if (bidAmount.lt(minimum)) {
        throw new HttpError(422, `La puja mínima es ${minimum.toFixed(2)}.`);
      }

      // Control optimista: solo actualiza si nadie pujó entre la lectura y la escritura.
      const updated = await tx.auction.updateMany({
        where: { id, status: AuctionStatus.ACTIVE, currentPrice: auction.currentPrice },
        data: { currentPrice: bidAmount },
      });
      if (updated.count === 0) {
        throw new HttpError(409, "Se registró otra puja antes que la tuya. Actualiza e inténtalo de nuevo.");
      }

      return tx.bid.create({
        data: { amount: bidAmount, auctionId: id, bidderId: session.userId },
      });
    });

    return NextResponse.json(bid, { status: 201 });
  } catch (error) {
    return handleError(error);
  }
}

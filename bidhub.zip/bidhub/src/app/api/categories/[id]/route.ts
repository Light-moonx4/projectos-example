import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import { handleError, HttpError } from "@/lib/http";
import { prisma } from "@/lib/prisma";
import { isUuid } from "@/lib/utils";

interface RouteContext {
  params: Promise<{ id: string }>;
}

/** onDelete: Restrict impide borrar categorías con subastas (responde 409). */
export async function DELETE(_request: NextRequest, context: RouteContext): Promise<NextResponse> {
  try {
    await requireAdmin();
    const { id } = await context.params;
    if (!isUuid(id)) throw new HttpError(404, "Categoría no encontrada.");

    const linked = await prisma.auction.count({ where: { categoryId: id } });
    if (linked > 0) {
      throw new HttpError(409, "No se puede eliminar la categoría porque tiene subastas asociadas.");
    }
    await prisma.category.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (error) {
    return handleError(error);
  }
}

import { NextResponse, type NextRequest } from "next/server";
import { ACCESS_COOKIE, ADMIN_PREFIXES, AUTH_PAGES, REFRESH_COOKIE } from "@/lib/constants";
import { verifyToken } from "@/lib/tokens";

function matchesPrefix(pathname: string, prefix: string): boolean {
  return pathname === prefix || pathname.startsWith(`${prefix}/`);
}

export async function middleware(request: NextRequest): Promise<NextResponse> {
  const { pathname, search } = request.nextUrl;
  const isApi = pathname.startsWith("/api/");
  const isAuthPage = AUTH_PAGES.some((page) => pathname === page);
  const isAdminArea = ADMIN_PREFIXES.some((prefix) => matchesPrefix(pathname, prefix));

  const accessToken = request.cookies.get(ACCESS_COOKIE)?.value;
  const session = accessToken ? await verifyToken(accessToken, "access") : null;

  // Usuarios autenticados no necesitan ver login/registro.
  if (isAuthPage) {
    if (session) {
      const target = session.role === "ADMIN" ? "/admin" : "/dashboard";
      return NextResponse.redirect(new URL(target, request.url));
    }
    return NextResponse.next();
  }

  // Sin access token válido.
  if (!session) {
    if (isApi) {
      return NextResponse.json({ error: "No autenticado." }, { status: 401 });
    }

    const hasRefreshToken = Boolean(request.cookies.get(REFRESH_COOKIE)?.value);
    if (hasRefreshToken) {
      // Intenta renovar la sesión y volver a la ruta solicitada.
      const refreshUrl = new URL("/api/auth/refresh", request.url);
      refreshUrl.searchParams.set("redirect", `${pathname}${search}`);
      return NextResponse.redirect(refreshUrl);
    }

    const loginUrl = new URL("/login", request.url);
    loginUrl.searchParams.set("next", `${pathname}${search}`);
    return NextResponse.redirect(loginUrl);
  }

  // Autenticado pero sin rol suficiente.
  if (isAdminArea && session.role !== "ADMIN") {
    if (isApi) {
      return NextResponse.json({ error: "Se requieren permisos de administrador." }, { status: 403 });
    }
    return NextResponse.redirect(new URL("/dashboard", request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    "/dashboard/:path*",
    "/publish/:path*",
    "/admin/:path*",
    "/login",
    "/register",
    "/api/moderation/:path*",
  ],
};

export const ACCESS_COOKIE = "bidhub_access";
export const REFRESH_COOKIE = "bidhub_refresh";

export const PRIVATE_PREFIXES = ["/dashboard", "/publish"] as const;
export const ADMIN_PREFIXES = ["/admin", "/api/moderation"] as const;
export const AUTH_PAGES = ["/login", "/register"] as const;

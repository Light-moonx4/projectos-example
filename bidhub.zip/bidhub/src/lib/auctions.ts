import { AuctionStatus, Prisma } from "@prisma/client";
import { prisma } from "./prisma";

export const auctionInclude = {
  category: { select: { id: true, name: true, slug: true } },
  seller: { select: { id: true, name: true } },
  _count: { select: { bids: true } },
} satisfies Prisma.AuctionInclude;

/**
 * Cierra las subastas activas cuya fecha de cierre ya pasó:
 * - Sin pujas -> DESERTED
 * - Con pujas -> CLOSED
 */
export async function closeExpiredAuctions(): Promise<void> {
  const now = new Date();
  await prisma.$transaction([
    prisma.auction.updateMany({
      where: { status: AuctionStatus.ACTIVE, closingDate: { lte: now }, bids: { none: {} } },
      data: { status: AuctionStatus.DESERTED },
    }),
    prisma.auction.updateMany({
      where: { status: AuctionStatus.ACTIVE, closingDate: { lte: now } },
      data: { status: AuctionStatus.CLOSED },
    }),
  ]);
}

import { AuctionStatus } from "@prisma/client";
import { z } from "zod";

const money = z.coerce.number().positive("Debe ser mayor que 0.").max(99999999.99, "El valor es demasiado alto.");

export const registerSchema = z.object({
  name: z.string().trim().min(2, "El nombre es muy corto.").max(80),
  email: z.string().trim().toLowerCase().email("Correo inválido."),
  password: z
    .string()
    .min(8, "La contraseña debe tener al menos 8 caracteres.")
    .max(72, "La contraseña no puede superar 72 caracteres.")
    .regex(/[A-Za-z]/, "Debe incluir al menos una letra.")
    .regex(/[0-9]/, "Debe incluir al menos un número."),
});

export const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email("Correo inválido."),
  password: z.string().min(1, "La contraseña es obligatoria."),
});

export const createAuctionSchema = z.object({
  title: z.string().trim().min(3).max(120),
  description: z.string().trim().min(10).max(2000),
  imageUrl: z.string().trim().url("La imagen debe ser una URL válida."),
  initialPrice: money,
  minimumIncrement: money,
  categoryId: z.string().uuid("Categoría inválida."),
  closingDate: z.coerce
    .date()
    .refine((date) => date.getTime() > Date.now() + 10 * 60 * 1000, "El cierre debe ser al menos 10 minutos en el futuro."),
});

export const bidSchema = z.object({ amount: money });

export const categorySchema = z.object({
  name: z.string().trim().min(2).max(60),
  description: z.string().trim().max(300).optional(),
});

export const cancelAuctionSchema = z.object({
  reason: z.string().trim().min(10, "El motivo debe tener al menos 10 caracteres.").max(500),
});

export const listAuctionsQuerySchema = z.object({
  category: z.string().trim().min(1).optional(),
  q: z.string().trim().min(1).max(100).optional(),
  status: z.nativeEnum(AuctionStatus).optional(),
  scope: z.enum(["all", "mine", "bidding"]).default("all"),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(50).default(12),
});

"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { extractError } from "@/lib/client";

interface BidFormProps {
  auctionId: string;
  minimumAmount: string;
}

export function BidForm({ auctionId, minimumAmount }: BidFormProps) {
  const router = useRouter();
  const [amount, setAmount] = useState(minimumAmount);
  const [error, setError] = useState<string | null>(null);
  const [needsLogin, setNeedsLogin] = useState(false);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setError(null);
    setNeedsLogin(false);
    try {
      const response = await fetch(`/api/auctions/${auctionId}/bids`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount: Number(amount) }),
      });
      if (response.status === 401) {
        setNeedsLogin(true);
        return;
      }
      if (!response.ok) {
        setError(await extractError(response));
        return;
      }
      router.refresh();
    } catch {
      setError("No se pudo conectar con el servidor.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      <label className="block text-sm font-medium" htmlFor="amount">
        Tu puja (mínimo {minimumAmount})
      </label>
      <input
        id="amount"
        type="number"
        step="0.01"
        min={minimumAmount}
        required
        value={amount}
        onChange={(event) => setAmount(event.target.value)}
        className="w-full rounded-md border border-slate-300 px-3 py-2"
      />
      {error && <p className="text-sm text-red-600">{error}</p>}
      {needsLogin && (
        <p className="text-sm text-amber-700">
          Debes{" "}
          <Link href={`/login?next=/auctions/${auctionId}`} className="underline">
            iniciar sesión
          </Link>{" "}
          para pujar.
        </p>
      )}
      <button
        type="submit"
        disabled={loading}
        className="w-full rounded-md bg-indigo-600 px-4 py-2 font-medium text-white hover:bg-indigo-700 disabled:opacity-50"
      >
        {loading ? "Enviando..." : "Pujar"}
      </button>
    </form>
  );
}

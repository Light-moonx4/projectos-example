import type { AuctionStatus } from "@/types";

const LABELS: Record<AuctionStatus, string> = {
  ACTIVE: "Activa",
  CLOSED: "Cerrada",
  DESERTED: "Desierta",
  CANCELED: "Cancelada",
};

const STYLES: Record<AuctionStatus, string> = {
  ACTIVE: "bg-emerald-100 text-emerald-700",
  CLOSED: "bg-slate-200 text-slate-700",
  DESERTED: "bg-amber-100 text-amber-700",
  CANCELED: "bg-red-100 text-red-700",
};

export function StatusBadge({ status }: { status: AuctionStatus }) {
  return (
    <span className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-medium ${STYLES[status]}`}>
      {LABELS[status]}
    </span>
  );
}

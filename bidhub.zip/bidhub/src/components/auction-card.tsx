import Link from "next/link";
import type { AuctionStatus } from "@/types";
import { formatDate, formatMoney } from "@/lib/utils";
import { StatusBadge } from "./status-badge";

export interface AuctionCardData {
  id: string;
  title: string;
  imageUrl: string;
  currentPrice: { toString(): string };
  closingDate: Date | string;
  status: AuctionStatus;
  category: { name: string };
  _count: { bids: number };
}

export function AuctionCard({ auction }: { auction: AuctionCardData }) {
  return (
    <Link
      href={`/auctions/${auction.id}`}
      className="group overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm transition hover:shadow-md"
    >
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={auction.imageUrl} alt={auction.title} className="h-44 w-full object-cover" loading="lazy" />
      <div className="space-y-2 p-4">
        <div className="flex items-center justify-between gap-2">
          <span className="text-xs font-medium uppercase tracking-wide text-indigo-600">{auction.category.name}</span>
          <StatusBadge status={auction.status} />
        </div>
        <h3 className="line-clamp-2 font-semibold group-hover:text-indigo-600">{auction.title}</h3>
        <p className="text-lg font-bold">{formatMoney(auction.currentPrice)}</p>
        <p className="text-xs text-slate-500">
          {auction._count.bids} {auction._count.bids === 1 ? "puja" : "pujas"} · Cierra {formatDate(auction.closingDate)}
        </p>
      </div>
    </Link>
  );
}

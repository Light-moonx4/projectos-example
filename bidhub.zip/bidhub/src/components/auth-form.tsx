"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { extractError } from "@/lib/client";
import { safeRedirectPath } from "@/lib/utils";
import type { AuthUserDTO } from "@/types";

interface AuthFormProps {
  mode: "login" | "register";
  next?: string;
}

export function AuthForm({ mode, next }: AuthFormProps) {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const isRegister = mode === "register";

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setError(null);

    const form = new FormData(event.currentTarget);
    const payload: Record<string, string> = {
      email: String(form.get("email") ?? ""),
      password: String(form.get("password") ?? ""),
    };
    if (isRegister) payload.name = String(form.get("name") ?? "");

    try {
      const response = await fetch(`/api/auth/${mode}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        setError(await extractError(response));
        return;
      }
      const data = (await response.json()) as { user: AuthUserDTO };
      const fallback = data.user.role === "ADMIN" ? "/admin" : "/dashboard";
      router.replace(safeRedirectPath(next, fallback));
      router.refresh();
    } catch {
      setError("No se pudo conectar con el servidor.");
    } finally {
      setLoading(false);
    }
  }

  const inputClass = "w-full rounded-md border border-slate-300 px-3 py-2";

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
      <h1 className="mb-1 text-2xl font-bold">{isRegister ? "Crear cuenta" : "Iniciar sesión"}</h1>
      <p className="mb-6 text-sm text-slate-500">
        {isRegister ? "Únete a BidHub y empieza a pujar." : "Ingresa para pujar y publicar subastas."}
      </p>
      <form onSubmit={handleSubmit} className="space-y-4">
        {isRegister && (
          <div>
            <label htmlFor="name" className="mb-1 block text-sm font-medium">
              Nombre
            </label>
            <input id="name" name="name" type="text" required minLength={2} className={inputClass} />
          </div>
        )}
        <div>
          <label htmlFor="email" className="mb-1 block text-sm font-medium">
            Correo
          </label>
          <input id="email" name="email" type="email" required autoComplete="email" className={inputClass} />
        </div>
        <div>
          <label htmlFor="password" className="mb-1 block text-sm font-medium">
            Contraseña
          </label>
          <input
            id="password"
            name="password"
            type="password"
            required
            minLength={isRegister ? 8 : 1}
            autoComplete={isRegister ? "new-password" : "current-password"}
            className={inputClass}
          />
        </div>
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          className="w-full rounded-md bg-indigo-600 px-4 py-2 font-medium text-white hover:bg-indigo-700 disabled:opacity-50"
        >
          {loading ? "Procesando..." : isRegister ? "Registrarme" : "Ingresar"}
        </button>
      </form>
      <p className="mt-4 text-center text-sm text-slate-500">
        {isRegister ? (
          <>
            ¿Ya tienes cuenta?{" "}
            <Link href="/login" className="text-indigo-600 hover:underline">
              Ingresa
            </Link>
          </>
        ) : (
          <>
            ¿No tienes cuenta?{" "}
            <Link href="/register" className="text-indigo-600 hover:underline">
              Regístrate
            </Link>
          </>
        )}
      </p>
    </div>
  );
}

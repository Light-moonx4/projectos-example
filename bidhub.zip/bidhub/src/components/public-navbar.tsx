import Link from "next/link";

export function PublicNavbar() {
  return (
    <header className="border-b border-slate-200 bg-white">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <Link href="/" className="text-xl font-bold text-indigo-600">
          BidHub
        </Link>
        <div className="flex items-center gap-4 text-sm font-medium">
          <Link href="/auctions" className="hover:text-indigo-600">
            Catálogo
          </Link>
          <Link href="/login" className="hover:text-indigo-600">
            Ingresar
          </Link>
          <Link href="/register" className="rounded-md bg-indigo-600 px-3 py-1.5 text-white hover:bg-indigo-700">
            Crear cuenta
          </Link>
        </div>
      </nav>
    </header>
  );
}

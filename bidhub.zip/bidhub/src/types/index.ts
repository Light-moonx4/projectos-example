export type Role = "USER" | "ADMIN";

export type AuctionStatus = "ACTIVE" | "CLOSED" | "DESERTED" | "CANCELED";

export interface ApiError {
  error: string;
  fields?: Record<string, string[] | undefined>;
}

export interface CategoryDTO {
  id: string;
  name: string;
  slug: string;
  description: string | null;
}

export interface AuctionSummaryDTO {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  initialPrice: string;
  minimumIncrement: string;
  currentPrice: string;
  closingDate: string;
  status: AuctionStatus;
  cancelReason: string | null;
  createdAt: string;
  category: { id: string; name: string; slug: string };
  seller: { id: string; name: string };
  _count: { bids: number };
}

export interface Paginated<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
}

export interface AuthUserDTO {
  id: string;
  name: string;
  email: string;
  role: Role;
}

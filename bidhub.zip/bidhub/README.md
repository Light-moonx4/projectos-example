# BidHub

Plataforma de subastas en línea. Next.js 16 (App Router) · TypeScript estricto · Prisma 6 · PostgreSQL (Supabase) · Tailwind 4 · JWT con `jose`.

## Puesta en marcha

```bash
npm install
cp .env.example .env        # completa DATABASE_URL, DIRECT_URL y los secretos JWT
npx prisma migrate dev --name init
npm run db:seed
npm run dev
```

Credenciales del seed: `admin@bidhub.com` / `Admin123!` (configurable con `SEED_ADMIN_PASSWORD`).
Usuarios demo: `vendedor@bidhub.com`, `ana@bidhub.com`, `carlos@bidhub.com` / `User12345!`.

## Rutas

| Grupo | URL | Render |
|---|---|---|
| (public) | `/` | SSG |
| (public) | `/auctions`, `/auctions/[id]` | SSR |
| (auth) | `/login`, `/register` | - |
| (private) | `/dashboard` (CSR), `/publish` | protegidas |
| (admin) | `/admin` | solo ADMIN |

## API

- `POST /api/auth/register | login | logout | refresh`, `GET /api/auth/me`
- `GET|POST /api/auctions`, `GET /api/auctions/[id]`, `POST /api/auctions/[id]/bids`
- `GET|POST /api/categories`, `DELETE /api/categories/[id]`
- `GET /api/moderation/auctions`, `POST /api/moderation/auctions/[id]/cancel`

## Notas

- `src/middleware.ts` lee las cookies HttpOnly. En Next.js 16 `middleware` sigue funcionando, pero la convención nueva es `proxy.ts` (renombra el archivo y la función exportada a `proxy`).
- Los refresh tokens se guardan hasheados con SHA-256 (no bcrypt: bcrypt trunca a 72 bytes y un JWT supera ese tamaño).
- Las subastas vencidas se cierran de forma perezosa (`closeExpiredAuctions`); para producción conviene un cron (Supabase pg_cron o Vercel Cron).

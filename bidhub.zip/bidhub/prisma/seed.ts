import { AuctionStatus, Prisma, PrismaClient, Role } from "@prisma/client";
import bcrypt from "bcrypt";

const prisma = new PrismaClient();

const ADMIN_EMAIL = "admin@bidhub.com";
const ADMIN_PASSWORD = process.env.SEED_ADMIN_PASSWORD ?? "Admin123!";
const DEFAULT_PASSWORD = process.env.SEED_DEFAULT_PASSWORD ?? "User12345!";
const SALT_ROUNDS = 12;

const HOUR_MS = 60 * 60 * 1000;
const DAY_MS = 24 * HOUR_MS;

function daysFromNow(days: number): Date {
  return new Date(Date.now() + days * DAY_MS);
}

interface CategorySeed {
  name: string;
  slug: string;
  description: string;
}

interface SeedBid {
  bidderEmail: string;
  amount: string;
}

interface AuctionSeed {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  categorySlug: string;
  initialPrice: string;
  minimumIncrement: string;
  status: AuctionStatus;
  closingDate: Date;
  cancelReason?: string;
  bids: SeedBid[];
}

const categories: CategorySeed[] = [
  { name: "Relojes", slug: "relojes", description: "Relojes de pulsera y de bolsillo, nuevos y de colección." },
  { name: "Cartas Coleccionables", slug: "cartas-coleccionables", description: "Cartas de TCG, ediciones limitadas y piezas gradadas." },
  { name: "Vinilos", slug: "vinilos", description: "Discos de vinilo, prensados originales y reediciones." },
  { name: "Cámaras Vintage", slug: "camaras-vintage", description: "Cámaras analógicas, lentes y accesorios clásicos." },
];

const SELLER_EMAIL = "vendedor@bidhub.com";
const BIDDER_ONE_EMAIL = "ana@bidhub.com";
const BIDDER_TWO_EMAIL = "carlos@bidhub.com";

const auctions: AuctionSeed[] = [
  {
    id: "00000000-0000-4000-8000-000000000001",
    title: "Reloj automático Seiko 1978",
    description: "Reloj automático en excelente estado, con caja de acero original y correa renovada. Funciona con precisión.",
    imageUrl: "https://picsum.photos/seed/bidhub-reloj-seiko/800/600",
    categorySlug: "relojes",
    initialPrice: "150.00",
    minimumIncrement: "10.00",
    status: AuctionStatus.ACTIVE,
    closingDate: daysFromNow(5),
    bids: [
      { bidderEmail: BIDDER_ONE_EMAIL, amount: "150.00" },
      { bidderEmail: BIDDER_TWO_EMAIL, amount: "165.00" },
      { bidderEmail: BIDDER_ONE_EMAIL, amount: "180.00" },
    ],
  },
  {
    id: "00000000-0000-4000-8000-000000000002",
    title: "Carta holográfica de primera edición",
    description: "Carta coleccionable holográfica de primera edición, protegida en funda rígida desde su apertura.",
    imageUrl: "https://picsum.photos/seed/bidhub-carta-holo/800/600",
    categorySlug: "cartas-coleccionables",
    initialPrice: "500.00",
    minimumIncrement: "25.00",
    status: AuctionStatus.ACTIVE,
    closingDate: daysFromNow(3),
    bids: [],
  },
  {
    id: "00000000-0000-4000-8000-000000000003",
    title: "Vinilo Abbey Road, prensado original",
    description: "Prensado original en muy buen estado, portada con mínimo desgaste y disco sin rayones visibles.",
    imageUrl: "https://picsum.photos/seed/bidhub-vinilo-abbey/800/600",
    categorySlug: "vinilos",
    initialPrice: "80.00",
    minimumIncrement: "5.00",
    status: AuctionStatus.ACTIVE,
    closingDate: daysFromNow(7),
    bids: [{ bidderEmail: BIDDER_TWO_EMAIL, amount: "80.00" }],
  },
  {
    id: "00000000-0000-4000-8000-000000000004",
    title: "Reloj digital clásico, edición limitada",
    description: "Reloj digital clásico de edición limitada, con caja original y manual.",
    imageUrl: "https://picsum.photos/seed/bidhub-reloj-digital/800/600",
    categorySlug: "relojes",
    initialPrice: "60.00",
    minimumIncrement: "5.00",
    status: AuctionStatus.CLOSED,
    closingDate: daysFromNow(-2),
    bids: [
      { bidderEmail: BIDDER_ONE_EMAIL, amount: "60.00" },
      { bidderEmail: BIDDER_TWO_EMAIL, amount: "70.00" },
      { bidderEmail: BIDDER_ONE_EMAIL, amount: "85.00" },
    ],
  },
  {
    id: "00000000-0000-4000-8000-000000000005",
    title: "Vinilo Kind of Blue, reedición",
    description: "Reedición en vinilo de 180 gramos, sellada de fábrica.",
    imageUrl: "https://picsum.photos/seed/bidhub-vinilo-jazz/800/600",
    categorySlug: "vinilos",
    initialPrice: "45.00",
    minimumIncrement: "5.00",
    status: AuctionStatus.DESERTED,
    closingDate: daysFromNow(-3),
    bids: [],
  },
  {
    id: "00000000-0000-4000-8000-000000000006",
    title: "Carta ilustrada edición promocional",
    description: "Carta promocional de evento, retirada por el administrador durante la moderación.",
    imageUrl: "https://picsum.photos/seed/bidhub-carta-promo/800/600",
    categorySlug: "cartas-coleccionables",
    initialPrice: "300.00",
    minimumIncrement: "20.00",
    status: AuctionStatus.CANCELED,
    closingDate: daysFromNow(4),
    cancelReason: "No se pudo verificar la autenticidad de la carta durante la moderación.",
    bids: [],
  },
];

async function upsertUser(name: string, email: string, password: string, role: Role): Promise<string> {
  const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);
  const user = await prisma.user.upsert({
    where: { email },
    create: { name, email, passwordHash, role },
    update: { name, passwordHash, role },
    select: { id: true },
  });
  return user.id;
}

async function main(): Promise<void> {
  console.log("Sembrando la base de datos de BidHub...");

  await upsertUser("Administrador BidHub", ADMIN_EMAIL, ADMIN_PASSWORD, Role.ADMIN);
  const sellerId = await upsertUser("Laura Vendedora", SELLER_EMAIL, DEFAULT_PASSWORD, Role.USER);
  const bidderIds = new Map<string, string>();
  bidderIds.set(BIDDER_ONE_EMAIL, await upsertUser("Ana Pujadora", BIDDER_ONE_EMAIL, DEFAULT_PASSWORD, Role.USER));
  bidderIds.set(BIDDER_TWO_EMAIL, await upsertUser("Carlos Pujador", BIDDER_TWO_EMAIL, DEFAULT_PASSWORD, Role.USER));

  const categoryIds = new Map<string, string>();
  for (const category of categories) {
    const saved = await prisma.category.upsert({
      where: { slug: category.slug },
      create: category,
      update: { name: category.name, description: category.description },
      select: { id: true },
    });
    categoryIds.set(category.slug, saved.id);
  }

  for (const auction of auctions) {
    const categoryId = categoryIds.get(auction.categorySlug);
    if (!categoryId) {
      throw new Error(`Categoría inexistente en el seed: ${auction.categorySlug}`);
    }

    const lastBid = auction.bids.at(-1);
    const data = {
      title: auction.title,
      description: auction.description,
      imageUrl: auction.imageUrl,
      initialPrice: new Prisma.Decimal(auction.initialPrice),
      minimumIncrement: new Prisma.Decimal(auction.minimumIncrement),
      currentPrice: new Prisma.Decimal(lastBid ? lastBid.amount : auction.initialPrice),
      closingDate: auction.closingDate,
      status: auction.status,
      cancelReason: auction.cancelReason ?? null,
      sellerId,
      categoryId,
    };

    await prisma.auction.upsert({
      where: { id: auction.id },
      create: { id: auction.id, ...data },
      update: data,
    });

    await prisma.bid.deleteMany({ where: { auctionId: auction.id } });

    if (auction.bids.length > 0) {
      await prisma.bid.createMany({
        data: auction.bids.map((bid, index) => {
          const bidderId = bidderIds.get(bid.bidderEmail);
          if (!bidderId) {
            throw new Error(`Postor inexistente en el seed: ${bid.bidderEmail}`);
          }
          return {
            auctionId: auction.id,
            bidderId,
            amount: new Prisma.Decimal(bid.amount),
            createdAt: new Date(Date.now() - (auction.bids.length - index) * HOUR_MS),
          };
        }),
      });
    }
  }

  console.log("Seed completado.");
  console.log(`  Admin: ${ADMIN_EMAIL} / ${ADMIN_PASSWORD}`);
  console.log(`  Usuarios demo: ${SELLER_EMAIL}, ${BIDDER_ONE_EMAIL}, ${BIDDER_TWO_EMAIL} / ${DEFAULT_PASSWORD}`);
}

main()
  .catch((error: unknown) => {
    console.error("Error ejecutando el seed:", error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

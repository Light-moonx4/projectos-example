import { BookStatus, LoanStatus, Prisma, PrismaClient, Role } from "@prisma/client";
import bcrypt from "bcrypt";

const prisma = new PrismaClient();

const ADMIN_EMAIL = "admin@libroloop.com";
const ADMIN_PASSWORD = process.env.SEED_ADMIN_PASSWORD ?? "Admin123!";
const DEFAULT_PASSWORD = process.env.SEED_DEFAULT_PASSWORD ?? "User12345!";
const SALT_ROUNDS = 12;
const DAY_MS = 24 * 60 * 60 * 1000;

const DONOR_EMAIL = "marta@libroloop.com";
const READER_ONE_EMAIL = "ana@libroloop.com";
const READER_TWO_EMAIL = "carlos@libroloop.com";

/** Fecha relativa a hoy: negativo = pasado, positivo = futuro. */
function days(offset: number): Date {
  return new Date(Date.now() + offset * DAY_MS);
}

interface CategorySeed {
  name: string;
  slug: string;
  description: string;
}

interface LoanSeed {
  userEmail: string;
  status: LoanStatus;
  loanedDaysAgo: number;
  dueInDays: number;
  returnedDaysAgo?: number;
  renewals?: number;
  fine?: string;
}

interface BookSeed {
  id: string;
  title: string;
  author: string;
  isbn?: string;
  description: string;
  coverUrl: string;
  categorySlug: string;
  /** Copias que posee actualmente la biblioteca (ya descontadas las perdidas). */
  totalCopies: number;
  status: BookStatus;
  moderationNote?: string;
  donorEmail: string;
  loans: LoanSeed[];
}

const categories: CategorySeed[] = [
  { name: "Novela", slug: "novela", description: "Narrativa clásica y contemporánea." },
  { name: "Ciencia Ficción", slug: "ciencia-ficcion", description: "Futuros posibles, espacio y tecnología." },
  { name: "Tecnología", slug: "tecnologia", description: "Programación, ingeniería y cultura digital." },
  { name: "Historia", slug: "historia", description: "Divulgación e historia universal." },
];

const books: BookSeed[] = [
  {
    id: "00000000-0000-4000-8000-0000000000a1",
    title: "Cien años de soledad",
    author: "Gabriel García Márquez",
    isbn: "978-0307474728",
    description: "La saga de la familia Buendía en Macondo, una de las grandes novelas del realismo mágico.",
    coverUrl: "https://picsum.photos/seed/libroloop-cien-anos/600/800",
    categorySlug: "novela",
    totalCopies: 3,
    status: BookStatus.ACTIVE,
    donorEmail: DONOR_EMAIL,
    loans: [
      { userEmail: READER_ONE_EMAIL, status: LoanStatus.ACTIVE, loanedDaysAgo: 3, dueInDays: 11 },
      { userEmail: READER_TWO_EMAIL, status: LoanStatus.RETURNED, loanedDaysAgo: 30, dueInDays: -16, returnedDaysAgo: 20 },
    ],
  },
  {
    id: "00000000-0000-4000-8000-0000000000a2",
    title: "Dune",
    author: "Frank Herbert",
    isbn: "978-0441172719",
    description: "Épica de ciencia ficción sobre poder, ecología y destino en el planeta desértico Arrakis.",
    coverUrl: "https://picsum.photos/seed/libroloop-dune/600/800",
    categorySlug: "ciencia-ficcion",
    totalCopies: 2,
    status: BookStatus.ACTIVE,
    donorEmail: DONOR_EMAIL,
    loans: [{ userEmail: READER_TWO_EMAIL, status: LoanStatus.OVERDUE, loanedDaysAgo: 25, dueInDays: -11 }],
  },
  {
    id: "00000000-0000-4000-8000-0000000000a3",
    title: "Clean Code",
    author: "Robert C. Martin",
    isbn: "978-0132350884",
    description: "Guía práctica para escribir código legible, mantenible y profesional.",
    coverUrl: "https://picsum.photos/seed/libroloop-clean-code/600/800",
    categorySlug: "tecnologia",
    totalCopies: 2,
    status: BookStatus.ACTIVE,
    donorEmail: DONOR_EMAIL,
    loans: [
      {
        userEmail: READER_ONE_EMAIL,
        status: LoanStatus.RETURNED,
        loanedDaysAgo: 40,
        dueInDays: -26,
        returnedDaysAgo: 20,
        renewals: 1,
        fine: "3.00",
      },
    ],
  },
  {
    id: "00000000-0000-4000-8000-0000000000a4",
    title: "Sapiens: de animales a dioses",
    author: "Yuval Noah Harari",
    isbn: "978-0062316097",
    description: "Un recorrido por la historia de la humanidad, desde la revolución cognitiva hasta hoy.",
    coverUrl: "https://picsum.photos/seed/libroloop-sapiens/600/800",
    categorySlug: "historia",
    totalCopies: 1,
    status: BookStatus.ACTIVE,
    donorEmail: DONOR_EMAIL,
    loans: [],
  },
  {
    id: "00000000-0000-4000-8000-0000000000a5",
    title: "El nombre del viento",
    author: "Patrick Rothfuss",
    isbn: "978-0756404741",
    description: "La historia de Kvothe, un joven prodigio que se convierte en leyenda.",
    coverUrl: "https://picsum.photos/seed/libroloop-nombre-viento/600/800",
    categorySlug: "novela",
    totalCopies: 2,
    status: BookStatus.ACTIVE,
    donorEmail: DONOR_EMAIL,
    loans: [
      {
        userEmail: READER_TWO_EMAIL,
        status: LoanStatus.LOST,
        loanedDaysAgo: 60,
        dueInDays: -46,
        fine: "20.00",
      },
    ],
  },
  {
    id: "00000000-0000-4000-8000-0000000000a6",
    title: "Fundación",
    author: "Isaac Asimov",
    isbn: "978-0553293357",
    description: "Donación pendiente de revisión: primer volumen de la saga de la Fundación.",
    coverUrl: "https://picsum.photos/seed/libroloop-fundacion/600/800",
    categorySlug: "ciencia-ficcion",
    totalCopies: 1,
    status: BookStatus.PENDING,
    donorEmail: READER_ONE_EMAIL,
    loans: [],
  },
  {
    id: "00000000-0000-4000-8000-0000000000a7",
    title: "Apuntes de cálculo (fotocopias)",
    author: "Autor desconocido",
    description: "Fotocopias encuadernadas de apuntes de un curso universitario de cálculo.",
    coverUrl: "https://picsum.photos/seed/libroloop-apuntes/600/800",
    categorySlug: "tecnologia",
    totalCopies: 1,
    status: BookStatus.REJECTED,
    moderationNote: "Material fotocopiado: no se aceptan reproducciones sin autorización del autor.",
    donorEmail: READER_TWO_EMAIL,
    loans: [],
  },
  {
    id: "00000000-0000-4000-8000-0000000000a8",
    title: "Almanaque mundial 1998",
    author: "Varios autores",
    isbn: "978-0000000018",
    description: "Almanaque con datos estadísticos de 1998, retirado por deterioro del ejemplar.",
    coverUrl: "https://picsum.photos/seed/libroloop-almanaque/600/800",
    categorySlug: "historia",
    totalCopies: 1,
    status: BookStatus.RETIRED,
    moderationNote: "Retirado del catálogo por deterioro del único ejemplar.",
    donorEmail: DONOR_EMAIL,
    loans: [],
  },
];

async function upsertUser(name: string, email: string, password: string, role: Role): Promise<string> {
  const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);
  const user = await prisma.user.upsert({
    where: { email },
    create: { name, email, passwordHash, role },
    update: { name, passwordHash, role },
    select: { id: true },
  });
  return user.id;
}

async function main(): Promise<void> {
  console.log("Sembrando la base de datos de LibroLoop...");

  const userIds = new Map<string, string>();
  userIds.set(ADMIN_EMAIL, await upsertUser("Administrador LibroLoop", ADMIN_EMAIL, ADMIN_PASSWORD, Role.ADMIN));
  userIds.set(DONOR_EMAIL, await upsertUser("Marta Donante", DONOR_EMAIL, DEFAULT_PASSWORD, Role.USER));
  userIds.set(READER_ONE_EMAIL, await upsertUser("Ana Lectora", READER_ONE_EMAIL, DEFAULT_PASSWORD, Role.USER));
  userIds.set(READER_TWO_EMAIL, await upsertUser("Carlos Lector", READER_TWO_EMAIL, DEFAULT_PASSWORD, Role.USER));

  const categoryIds = new Map<string, string>();
  for (const category of categories) {
    const saved = await prisma.category.upsert({
      where: { slug: category.slug },
      create: category,
      update: { name: category.name, description: category.description },
      select: { id: true },
    });
    categoryIds.set(category.slug, saved.id);
  }

  for (const book of books) {
    const categoryId = categoryIds.get(book.categorySlug);
    const donorId = userIds.get(book.donorEmail);
    if (!categoryId || !donorId) {
      throw new Error(`Referencias inválidas en el seed para el libro "${book.title}".`);
    }

    const openLoans = book.loans.filter(
      (loan) => loan.status === LoanStatus.ACTIVE || loan.status === LoanStatus.OVERDUE,
    ).length;

    const data = {
      title: book.title,
      author: book.author,
      isbn: book.isbn ?? null,
      description: book.description,
      coverUrl: book.coverUrl,
      totalCopies: book.totalCopies,
      availableCopies: Math.max(book.totalCopies - openLoans, 0),
      status: book.status,
      moderationNote: book.moderationNote ?? null,
      donorId,
      categoryId,
    };

    await prisma.book.upsert({
      where: { id: book.id },
      create: { id: book.id, ...data },
      update: data,
    });

    await prisma.loan.deleteMany({ where: { bookId: book.id } });

    for (const loan of book.loans) {
      const userId = userIds.get(loan.userEmail);
      if (!userId) throw new Error(`Usuario inexistente en el seed: ${loan.userEmail}`);

      await prisma.loan.create({
        data: {
          bookId: book.id,
          userId,
          status: loan.status,
          loanedAt: days(-loan.loanedDaysAgo),
          dueDate: days(loan.dueInDays),
          returnedAt: loan.returnedDaysAgo !== undefined ? days(-loan.returnedDaysAgo) : null,
          renewals: loan.renewals ?? 0,
          fineAmount: new Prisma.Decimal(loan.fine ?? "0.00"),
        },
      });
    }
  }

  console.log("Seed completado.");
  console.log(`  Admin: ${ADMIN_EMAIL} / ${ADMIN_PASSWORD}`);
  console.log(
    `  Usuarios demo: ${DONOR_EMAIL}, ${READER_ONE_EMAIL}, ${READER_TWO_EMAIL} / ${DEFAULT_PASSWORD}`,
  );
}

main()
  .catch((error: unknown) => {
    console.error("Error ejecutando el seed:", error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

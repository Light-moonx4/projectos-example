"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { extractError } from "@/lib/client";

interface BorrowButtonProps {
  bookId: string;
  disabled?: boolean;
}

export function BorrowButton({ bookId, disabled = false }: BorrowButtonProps) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [needsLogin, setNeedsLogin] = useState(false);
  const [done, setDone] = useState(false);

  async function handleBorrow() {
    setLoading(true);
    setError(null);
    setNeedsLogin(false);
    try {
      const response = await fetch("/api/loans", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ bookId }),
      });
      if (response.status === 401) {
        setNeedsLogin(true);
        return;
      }
      if (!response.ok) {
        setError(await extractError(response));
        return;
      }
      setDone(true);
      router.refresh();
    } catch {
      setError("No se pudo conectar con el servidor.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-3">
      <button
        type="button"
        onClick={() => void handleBorrow()}
        disabled={disabled || loading || done}
        className="w-full rounded-md bg-indigo-600 px-4 py-2 font-medium text-white hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-50"
      >
        {loading ? "Procesando..." : done ? "Préstamo registrado" : "Pedir prestado"}
      </button>
      {done && (
        <p className="text-sm text-emerald-700">
          Listo. Revisa la fecha de devolución en{" "}
          <Link href="/dashboard" className="underline">
            tu panel
          </Link>
          .
        </p>
      )}
      {error && <p className="text-sm text-red-600">{error}</p>}
      {needsLogin && (
        <p className="text-sm text-amber-700">
          Debes{" "}
          <Link href={`/login?next=/books/${bookId}`} className="underline">
            iniciar sesión
          </Link>{" "}
          para pedir libros.
        </p>
      )}
    </div>
  );
}

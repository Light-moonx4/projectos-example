import Link from "next/link";
import { LogoutButton } from "./logout-button";

export function PrivateNav() {
  return (
    <header className="border-b border-slate-200 bg-white">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <Link href="/dashboard" className="text-xl font-bold text-indigo-600">
          LibroLoop
        </Link>
        <div className="flex items-center gap-4 text-sm font-medium">
          <Link href="/books" className="hover:text-indigo-600">
            Catálogo
          </Link>
          <Link href="/dashboard" className="hover:text-indigo-600">
            Mi panel
          </Link>
          <Link href="/donate" className="hover:text-indigo-600">
            Donar libro
          </Link>
          <LogoutButton className="rounded-md border border-slate-300 px-3 py-1.5 hover:bg-slate-100 disabled:opacity-50" />
        </div>
      </nav>
    </header>
  );
}

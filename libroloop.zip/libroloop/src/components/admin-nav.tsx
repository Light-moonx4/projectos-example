import Link from "next/link";
import { LogoutButton } from "./logout-button";

export function AdminNav() {
  return (
    <header className="bg-slate-900 text-white">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <Link href="/admin" className="text-xl font-bold">
          LibroLoop <span className="text-sm font-normal text-slate-400">· Gestión</span>
        </Link>
        <div className="flex items-center gap-4 text-sm font-medium">
          <Link href="/books" className="hover:text-indigo-300">
            Ver sitio
          </Link>
          <LogoutButton className="rounded-md border border-slate-600 px-3 py-1.5 hover:bg-slate-800 disabled:opacity-50" />
        </div>
      </nav>
    </header>
  );
}

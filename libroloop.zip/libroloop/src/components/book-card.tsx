import Link from "next/link";

export interface BookCardData {
  id: string;
  title: string;
  author: string;
  coverUrl: string;
  availableCopies: number;
  totalCopies: number;
  category: { name: string };
}

export function BookCard({ book }: { book: BookCardData }) {
  const available = book.availableCopies > 0;
  return (
    <Link
      href={`/books/${book.id}`}
      className="group overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm transition hover:shadow-md"
    >
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={book.coverUrl} alt={`Portada de ${book.title}`} className="h-64 w-full object-cover" loading="lazy" />
      <div className="space-y-1.5 p-4">
        <span className="text-xs font-medium uppercase tracking-wide text-indigo-600">{book.category.name}</span>
        <h3 className="line-clamp-2 font-semibold group-hover:text-indigo-600">{book.title}</h3>
        <p className="text-sm text-slate-600">{book.author}</p>
        <p className={`text-xs font-medium ${available ? "text-emerald-600" : "text-red-600"}`}>
          {available
            ? `${book.availableCopies} de ${book.totalCopies} copias disponibles`
            : "Sin copias disponibles"}
        </p>
      </div>
    </Link>
  );
}

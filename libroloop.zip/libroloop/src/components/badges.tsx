import type { BookStatus, LoanStatus } from "@/types";

const BOOK_LABELS: Record<BookStatus, string> = {
  PENDING: "Pendiente",
  ACTIVE: "Activo",
  REJECTED: "Rechazado",
  RETIRED: "Retirado",
};

const BOOK_STYLES: Record<BookStatus, string> = {
  PENDING: "bg-amber-100 text-amber-700",
  ACTIVE: "bg-emerald-100 text-emerald-700",
  REJECTED: "bg-red-100 text-red-700",
  RETIRED: "bg-slate-200 text-slate-700",
};

const LOAN_LABELS: Record<LoanStatus, string> = {
  ACTIVE: "En préstamo",
  RETURNED: "Devuelto",
  OVERDUE: "Vencido",
  LOST: "Perdido",
};

const LOAN_STYLES: Record<LoanStatus, string> = {
  ACTIVE: "bg-sky-100 text-sky-700",
  RETURNED: "bg-emerald-100 text-emerald-700",
  OVERDUE: "bg-red-100 text-red-700",
  LOST: "bg-slate-300 text-slate-800",
};

const BASE = "inline-block rounded-full px-2.5 py-0.5 text-xs font-medium";

export function BookStatusBadge({ status }: { status: BookStatus }) {
  return <span className={`${BASE} ${BOOK_STYLES[status]}`}>{BOOK_LABELS[status]}</span>;
}

export function LoanStatusBadge({ status }: { status: LoanStatus }) {
  return <span className={`${BASE} ${LOAN_STYLES[status]}`}>{LOAN_LABELS[status]}</span>;
}

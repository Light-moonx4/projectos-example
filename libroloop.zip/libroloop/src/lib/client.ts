import type { ApiError } from "@/types";

export async function extractError(response: Response): Promise<string> {
  try {
    const data = (await response.json()) as Partial<ApiError>;
    return data.error ?? "Ocurrió un error inesperado.";
  } catch {
    return "Ocurrió un error inesperado.";
  }
}

import { LoanStatus, Prisma } from "@prisma/client";
import { prisma } from "./prisma";

export const bookInclude = {
  category: { select: { id: true, name: true, slug: true } },
  donor: { select: { id: true, name: true } },
} satisfies Prisma.BookInclude;

export const loanInclude = {
  book: { select: { id: true, title: true, author: true, coverUrl: true } },
  user: { select: { id: true, name: true, email: true } },
} satisfies Prisma.LoanInclude;

/** Marca como OVERDUE los préstamos activos cuya fecha de entrega ya venció. */
export async function markOverdueLoans(): Promise<void> {
  await prisma.loan.updateMany({
    where: { status: LoanStatus.ACTIVE, dueDate: { lt: new Date() } },
    data: { status: LoanStatus.OVERDUE },
  });
}

export const OPEN_LOAN_STATUSES: LoanStatus[] = [LoanStatus.ACTIVE, LoanStatus.OVERDUE];

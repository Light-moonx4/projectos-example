export const ACCESS_COOKIE = "libroloop_access";
export const REFRESH_COOKIE = "libroloop_refresh";

export const PRIVATE_PREFIXES = ["/dashboard", "/donate"] as const;
export const ADMIN_PREFIXES = ["/admin", "/api/management"] as const;
export const AUTH_PAGES = ["/login", "/register"] as const;

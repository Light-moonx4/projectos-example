import type { NextResponse } from "next/server";
import { ACCESS_COOKIE, REFRESH_COOKIE } from "./constants";
import { durationToSeconds, getExpiresIn } from "./tokens";

const baseOptions = {
  httpOnly: true,
  secure: process.env.NODE_ENV === "production",
  sameSite: "lax" as const,
  path: "/",
};

export function setAuthCookies(response: NextResponse, accessToken: string, refreshToken: string): void {
  response.cookies.set({
    ...baseOptions,
    name: ACCESS_COOKIE,
    value: accessToken,
    maxAge: durationToSeconds(getExpiresIn("access")),
  });
  response.cookies.set({
    ...baseOptions,
    name: REFRESH_COOKIE,
    value: refreshToken,
    maxAge: durationToSeconds(getExpiresIn("refresh")),
  });
}

export function clearAuthCookies(response: NextResponse): void {
  response.cookies.set({ ...baseOptions, name: ACCESS_COOKIE, value: "", maxAge: 0 });
  response.cookies.set({ ...baseOptions, name: REFRESH_COOKIE, value: "", maxAge: 0 });
}

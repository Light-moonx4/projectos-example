import { SignJWT, jwtVerify } from "jose";
import type { Role } from "@prisma/client";

export type TokenType = "access" | "refresh";

export interface SessionClaims {
  userId: string;
  role: Role;
}

const encoder = new TextEncoder();

function isRole(value: unknown): value is Role {
  return value === "USER" || value === "ADMIN";
}

function getSecret(type: TokenType): Uint8Array {
  const name = type === "access" ? "JWT_ACCESS_SECRET" : "JWT_REFRESH_SECRET";
  const value = process.env[name];
  if (!value || value.length < 32) {
    throw new Error(`La variable de entorno ${name} debe existir y tener al menos 32 caracteres.`);
  }
  return encoder.encode(value);
}

export function getExpiresIn(type: TokenType): string {
  const raw = type === "access" ? process.env.ACCESS_TOKEN_EXPIRES_IN : process.env.REFRESH_TOKEN_EXPIRES_IN;
  return raw ?? (type === "access" ? "15m" : "7d");
}

export function durationToSeconds(duration: string): number {
  const match = /^(\d+)([smhd])$/.exec(duration);
  if (!match) {
    throw new Error(`Duración inválida "${duration}". Usa formatos como 15m, 12h o 7d.`);
  }
  const amount = Number(match[1]);
  const multipliers: Record<string, number> = { s: 1, m: 60, h: 3600, d: 86400 };
  return amount * multipliers[match[2]];
}

export async function signToken(claims: SessionClaims, type: TokenType): Promise<string> {
  return new SignJWT({ role: claims.role, type })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(claims.userId)
    .setJti(crypto.randomUUID())
    .setIssuedAt()
    .setExpirationTime(getExpiresIn(type))
    .sign(getSecret(type));
}

export async function verifyToken(token: string, type: TokenType): Promise<SessionClaims | null> {
  const secret = getSecret(type);
  try {
    const { payload } = await jwtVerify(token, secret, { algorithms: ["HS256"] });
    const role = payload.role;
    if (payload.type !== type || typeof payload.sub !== "string" || !isRole(role)) {
      return null;
    }
    return { userId: payload.sub, role };
  } catch {
    return null;
  }
}

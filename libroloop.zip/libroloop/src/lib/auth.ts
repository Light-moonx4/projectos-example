import { cookies } from "next/headers";
import { Role } from "@prisma/client";
import { ACCESS_COOKIE } from "./constants";
import { hashToken } from "./crypto";
import { HttpError } from "./http";
import { prisma } from "./prisma";
import { signToken, verifyToken, type SessionClaims } from "./tokens";

export async function getSession(): Promise<SessionClaims | null> {
  const store = await cookies();
  const token = store.get(ACCESS_COOKIE)?.value;
  if (!token) return null;
  return verifyToken(token, "access");
}

export async function requireAuth(): Promise<SessionClaims> {
  const session = await getSession();
  if (!session) throw new HttpError(401, "No autenticado.");
  return session;
}

export async function requireAdmin(): Promise<SessionClaims> {
  const session = await requireAuth();
  if (session.role !== Role.ADMIN) throw new HttpError(403, "Se requieren permisos de administrador.");
  return session;
}

export interface IssuedTokens {
  accessToken: string;
  refreshToken: string;
}

export async function issueSession(user: { id: string; role: Role }): Promise<IssuedTokens> {
  const claims: SessionClaims = { userId: user.id, role: user.role };
  const [accessToken, refreshToken] = await Promise.all([
    signToken(claims, "access"),
    signToken(claims, "refresh"),
  ]);
  await prisma.user.update({
    where: { id: user.id },
    data: { refreshTokenHash: hashToken(refreshToken) },
  });
  return { accessToken, refreshToken };
}

import { NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { ZodError } from "zod";

export class HttpError extends Error {
  readonly status: number;

  constructor(status: number, message: string) {
    super(message);
    this.name = "HttpError";
    this.status = status;
  }
}

export function json<T>(data: T, status = 200): NextResponse {
  return NextResponse.json(data, { status });
}

export async function readJson(request: Request): Promise<unknown> {
  try {
    return await request.json();
  } catch {
    throw new HttpError(400, "El cuerpo de la petición debe ser un JSON válido.");
  }
}

export function handleError(error: unknown): NextResponse {
  if (error instanceof HttpError) {
    return NextResponse.json({ error: error.message }, { status: error.status });
  }
  if (error instanceof ZodError) {
    return NextResponse.json(
      { error: "Datos inválidos.", fields: error.flatten().fieldErrors },
      { status: 422 },
    );
  }
  if (error instanceof Prisma.PrismaClientKnownRequestError) {
    if (error.code === "P2002") {
      return NextResponse.json({ error: "Ya existe un registro con esos datos únicos." }, { status: 409 });
    }
    if (error.code === "P2003") {
      return NextResponse.json(
        { error: "La operación no es posible porque existen registros asociados." },
        { status: 409 },
      );
    }
    if (error.code === "P2025") {
      return NextResponse.json({ error: "Registro no encontrado." }, { status: 404 });
    }
  }
  console.error(error);
  return NextResponse.json({ error: "Error interno del servidor." }, { status: 500 });
}

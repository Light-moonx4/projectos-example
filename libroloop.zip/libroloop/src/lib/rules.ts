import { Prisma } from "@prisma/client";

export const DAY_MS = 24 * 60 * 60 * 1000;

/** Días que dura un préstamo nuevo. */
export const LOAN_DAYS = 14;
/** Días extra que otorga una renovación. */
export const RENEWAL_DAYS = 7;
/** Renovaciones permitidas por préstamo. */
export const MAX_RENEWALS = 1;
/** Máximo de préstamos abiertos (ACTIVE + OVERDUE) por usuario. */
export const MAX_OPEN_LOANS = 3;
/** Multa por cada día de atraso. */
export const FINE_PER_DAY = new Prisma.Decimal("0.50");
/** Cargo fijo por libro perdido. */
export const LOST_BOOK_FEE = new Prisma.Decimal("20.00");
/** Máximo de copias que un usuario puede donar en una sola publicación. */
export const MAX_DONATED_COPIES = 5;

export function addDays(date: Date, days: number): Date {
  return new Date(date.getTime() + days * DAY_MS);
}

/** Días completos de atraso (redondeo hacia arriba). 0 si se devolvió a tiempo. */
export function daysLate(dueDate: Date, returnedAt: Date): number {
  const diff = returnedAt.getTime() - dueDate.getTime();
  return diff > 0 ? Math.ceil(diff / DAY_MS) : 0;
}

export function calculateFine(dueDate: Date, returnedAt: Date): Prisma.Decimal {
  return FINE_PER_DAY.mul(daysLate(dueDate, returnedAt));
}

import { BookStatus, LoanStatus } from "@prisma/client";
import { z } from "zod";
import { MAX_DONATED_COPIES } from "./rules";

export const registerSchema = z.object({
  name: z.string().trim().min(2, "El nombre es muy corto.").max(80),
  email: z.string().trim().toLowerCase().email("Correo inválido."),
  password: z
    .string()
    .min(8, "La contraseña debe tener al menos 8 caracteres.")
    .max(72, "La contraseña no puede superar 72 caracteres.")
    .regex(/[A-Za-z]/, "Debe incluir al menos una letra.")
    .regex(/[0-9]/, "Debe incluir al menos un número."),
});

export const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email("Correo inválido."),
  password: z.string().min(1, "La contraseña es obligatoria."),
});

export const categorySchema = z.object({
  name: z.string().trim().min(2).max(60),
  description: z.string().trim().max(300).optional(),
});

export const createBookSchema = z.object({
  title: z.string().trim().min(2).max(160),
  author: z.string().trim().min(2).max(120),
  isbn: z
    .string()
    .trim()
    .regex(/^[0-9Xx-]{10,17}$/, "ISBN inválido.")
    .optional()
    .or(z.literal("").transform(() => undefined)),
  description: z.string().trim().min(10).max(2000),
  coverUrl: z.string().trim().url("La portada debe ser una URL válida."),
  categoryId: z.string().uuid("Categoría inválida."),
  totalCopies: z.coerce.number().int().min(1).max(MAX_DONATED_COPIES),
});

export const listBooksQuerySchema = z.object({
  category: z.string().trim().min(1).optional(),
  q: z.string().trim().min(1).max(100).optional(),
  status: z.nativeEnum(BookStatus).optional(),
  scope: z.enum(["all", "mine"]).default("all"),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(50).default(12),
});

export const reviewBookSchema = z
  .object({
    decision: z.enum(["APPROVE", "REJECT", "RETIRE"]),
    note: z.string().trim().max(500).optional(),
  })
  .refine((value) => value.decision === "APPROVE" || (value.note?.length ?? 0) >= 10, {
    message: "Rechazar o retirar un libro requiere una nota de al menos 10 caracteres.",
    path: ["note"],
  });

export const borrowSchema = z.object({ bookId: z.string().uuid("Libro inválido.") });

export const listLoansQuerySchema = z.object({
  status: z.nativeEnum(LoanStatus).optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(50).default(20),
});

import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { BookStatus, Role } from "@prisma/client";
import { BookStatusBadge } from "@/components/badges";
import { BorrowButton } from "@/components/borrow-button";
import { getSession } from "@/lib/auth";
import { bookInclude } from "@/lib/loans";
import { prisma } from "@/lib/prisma";
import { FINE_PER_DAY, LOAN_DAYS } from "@/lib/rules";
import { formatMoney, isUuid } from "@/lib/utils";

// Detalle renderizado en cada petición (SSR).
export const dynamic = "force-dynamic";

interface BookDetailPageProps {
  params: Promise<{ id: string }>;
}

export async function generateMetadata({ params }: BookDetailPageProps): Promise<Metadata> {
  const { id } = await params;
  if (!isUuid(id)) return { title: "Libro no encontrado" };
  const book = await prisma.book.findUnique({ where: { id }, select: { title: true, status: true } });
  return { title: book && book.status === BookStatus.ACTIVE ? book.title : "Libro" };
}

export default async function BookDetailPage({ params }: BookDetailPageProps) {
  const { id } = await params;
  if (!isUuid(id)) notFound();

  const book = await prisma.book.findUnique({ where: { id }, include: bookInclude });
  if (!book) notFound();

  // Los libros no aprobados solo los ven su donante y los administradores.
  if (book.status !== BookStatus.ACTIVE) {
    const session = await getSession();
    const allowed = session && (session.role === Role.ADMIN || session.userId === book.donorId);
    if (!allowed) notFound();
  }

  const isActive = book.status === BookStatus.ACTIVE;
  const hasCopies = book.availableCopies > 0;

  return (
    <div className="grid gap-8 lg:grid-cols-3">
      <div className="lg:col-span-1">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={book.coverUrl} alt={`Portada de ${book.title}`} className="w-full rounded-xl object-cover shadow" />
      </div>

      <div className="space-y-4 lg:col-span-2">
        <div className="flex items-center gap-3">
          <span className="text-xs font-medium uppercase tracking-wide text-indigo-600">{book.category.name}</span>
          <BookStatusBadge status={book.status} />
        </div>
        <h1 className="text-3xl font-bold">{book.title}</h1>
        <p className="text-lg text-slate-600">{book.author}</p>
        <p className="whitespace-pre-line text-slate-700">{book.description}</p>
        <dl className="grid max-w-md grid-cols-2 gap-y-1 text-sm">
          {book.isbn && (
            <>
              <dt className="text-slate-500">ISBN</dt>
              <dd>{book.isbn}</dd>
            </>
          )}
          <dt className="text-slate-500">Donado por</dt>
          <dd>{book.donor.name}</dd>
          <dt className="text-slate-500">Copias</dt>
          <dd>
            {book.availableCopies} disponibles de {book.totalCopies}
          </dd>
        </dl>

        {book.moderationNote && (
          <p className="rounded-md bg-slate-100 p-3 text-sm">Nota de moderación: {book.moderationNote}</p>
        )}

        {isActive ? (
          <aside className="max-w-md space-y-3 rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <BorrowButton bookId={book.id} disabled={!hasCopies} />
            {!hasCopies && <p className="text-sm text-red-600">No hay copias disponibles por ahora.</p>}
            <p className="text-xs text-slate-500">
              Préstamo de {LOAN_DAYS} días. Multa por atraso: {formatMoney(FINE_PER_DAY)} por día.
            </p>
          </aside>
        ) : (
          <p className="rounded-md bg-amber-50 p-3 text-sm text-amber-800">
            Este libro no está disponible para préstamo.
          </p>
        )}
      </div>
    </div>
  );
}

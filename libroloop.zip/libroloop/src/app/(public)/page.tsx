import Link from "next/link";
import { LOAN_DAYS, MAX_OPEN_LOANS, RENEWAL_DAYS } from "@/lib/rules";

// Home generada estáticamente en build (SSG): no consulta la base de datos.
export const dynamic = "force-static";

const rules = [
  { title: `${LOAN_DAYS} días de préstamo`, text: `Renueva una vez y suma ${RENEWAL_DAYS} días más si no estás atrasado.` },
  { title: `Hasta ${MAX_OPEN_LOANS} libros a la vez`, text: "Devuelve para seguir leyendo; con préstamos vencidos no puedes pedir otro." },
  { title: "Dona y comparte", text: "Propón tus libros: el equipo los revisa y los suma al catálogo." },
];

export default function HomePage() {
  return (
    <div className="space-y-12">
      <section className="rounded-2xl bg-indigo-600 px-6 py-16 text-center text-white">
        <h1 className="mb-4 text-4xl font-bold">Una biblioteca hecha por la comunidad</h1>
        <p className="mx-auto mb-8 max-w-xl text-indigo-100">
          Pide libros prestados, dona los que ya leíste y mantén vivo el ciclo de la lectura.
        </p>
        <div className="flex justify-center gap-3">
          <Link href="/books" className="rounded-md bg-white px-5 py-2.5 font-medium text-indigo-700 hover:bg-indigo-50">
            Explorar catálogo
          </Link>
          <Link href="/register" className="rounded-md border border-white px-5 py-2.5 font-medium hover:bg-indigo-500">
            Crear cuenta
          </Link>
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-3">
        {rules.map((item) => (
          <article key={item.title} className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <h2 className="mb-2 font-semibold">{item.title}</h2>
            <p className="text-sm text-slate-600">{item.text}</p>
          </article>
        ))}
      </section>
    </div>
  );
}

import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { BookStatus, Prisma, Role } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { handleError, HttpError, readJson } from "@/lib/http";
import { bookInclude } from "@/lib/loans";
import { prisma } from "@/lib/prisma";
import { createBookSchema, listBooksQuerySchema } from "@/lib/validators";

export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    const query = listBooksQuerySchema.parse(Object.fromEntries(request.nextUrl.searchParams));
    const where: Prisma.BookWhereInput = {};

    if (query.scope === "mine") {
      const session = await requireAuth();
      where.donorId = session.userId;
      if (query.status) where.status = query.status;
    } else {
      // El catálogo público solo muestra libros aprobados.
      where.status = BookStatus.ACTIVE;
    }

    if (query.category) where.category = { slug: query.category };
    if (query.q) {
      where.OR = [
        { title: { contains: query.q, mode: "insensitive" } },
        { author: { contains: query.q, mode: "insensitive" } },
      ];
    }

    const [items, total] = await prisma.$transaction([
      prisma.book.findMany({
        where,
        include: bookInclude,
        orderBy: { createdAt: "desc" },
        skip: (query.page - 1) * query.pageSize,
        take: query.pageSize,
      }),
      prisma.book.count({ where }),
    ]);

    return NextResponse.json({ items, total, page: query.page, pageSize: query.pageSize });
  } catch (error) {
    return handleError(error);
  }
}

/** Un usuario dona un libro (queda PENDING); un administrador lo publica directo (ACTIVE). */
export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const session = await requireAuth();
    const input = createBookSchema.parse(await readJson(request));

    const category = await prisma.category.findUnique({ where: { id: input.categoryId }, select: { id: true } });
    if (!category) throw new HttpError(404, "La categoría seleccionada no existe.");

    const book = await prisma.book.create({
      data: {
        title: input.title,
        author: input.author,
        isbn: input.isbn ?? null,
        description: input.description,
        coverUrl: input.coverUrl,
        totalCopies: input.totalCopies,
        availableCopies: input.totalCopies,
        status: session.role === Role.ADMIN ? BookStatus.ACTIVE : BookStatus.PENDING,
        donorId: session.userId,
        categoryId: input.categoryId,
      },
      include: bookInclude,
    });

    return NextResponse.json(book, { status: 201 });
  } catch (error) {
    return handleError(error);
  }
}

import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { BookStatus, Role } from "@prisma/client";
import { getSession } from "@/lib/auth";
import { handleError, HttpError } from "@/lib/http";
import { bookInclude } from "@/lib/loans";
import { prisma } from "@/lib/prisma";
import { isUuid } from "@/lib/utils";

interface RouteContext {
  params: Promise<{ id: string }>;
}

export async function GET(_request: NextRequest, context: RouteContext): Promise<NextResponse> {
  try {
    const { id } = await context.params;
    if (!isUuid(id)) throw new HttpError(404, "Libro no encontrado.");

    const book = await prisma.book.findUnique({ where: { id }, include: bookInclude });
    if (!book) throw new HttpError(404, "Libro no encontrado.");

    // Los libros no aprobados solo los ven su donante y los administradores.
    if (book.status !== BookStatus.ACTIVE) {
      const session = await getSession();
      const allowed = session && (session.role === Role.ADMIN || session.userId === book.donorId);
      if (!allowed) throw new HttpError(404, "Libro no encontrado.");
    }

    return NextResponse.json(book);
  } catch (error) {
    return handleError(error);
  }
}

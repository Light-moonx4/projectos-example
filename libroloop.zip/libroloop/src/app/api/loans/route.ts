import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { BookStatus, LoanStatus } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { handleError, HttpError, readJson } from "@/lib/http";
import { loanInclude, markOverdueLoans, OPEN_LOAN_STATUSES } from "@/lib/loans";
import { prisma } from "@/lib/prisma";
import { addDays, LOAN_DAYS, MAX_OPEN_LOANS } from "@/lib/rules";
import { borrowSchema, listLoansQuerySchema } from "@/lib/validators";

/** Préstamos del usuario autenticado. */
export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    const session = await requireAuth();
    const query = listLoansQuerySchema.parse(Object.fromEntries(request.nextUrl.searchParams));
    await markOverdueLoans();

    const where = { userId: session.userId, ...(query.status ? { status: query.status } : {}) };
    const [items, total] = await prisma.$transaction([
      prisma.loan.findMany({
        where,
        include: loanInclude,
        orderBy: { loanedAt: "desc" },
        skip: (query.page - 1) * query.pageSize,
        take: query.pageSize,
      }),
      prisma.loan.count({ where }),
    ]);

    return NextResponse.json({ items, total, page: query.page, pageSize: query.pageSize });
  } catch (error) {
    return handleError(error);
  }
}

/** Solicita un libro prestado aplicando las reglas de la biblioteca. */
export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const session = await requireAuth();
    const { bookId } = borrowSchema.parse(await readJson(request));
    await markOverdueLoans();

    const loan = await prisma.$transaction(async (tx) => {
      const openLoans = await tx.loan.findMany({
        where: { userId: session.userId, status: { in: OPEN_LOAN_STATUSES } },
        select: { bookId: true, status: true },
      });

      if (openLoans.some((item) => item.status === LoanStatus.OVERDUE)) {
        throw new HttpError(403, "Tienes préstamos vencidos. Devuélvelos antes de pedir otro libro.");
      }
      if (openLoans.length >= MAX_OPEN_LOANS) {
        throw new HttpError(409, `Alcanzaste el máximo de ${MAX_OPEN_LOANS} préstamos abiertos.`);
      }
      if (openLoans.some((item) => item.bookId === bookId)) {
        throw new HttpError(409, "Ya tienes un préstamo abierto de este libro.");
      }

      const book = await tx.book.findUnique({ where: { id: bookId }, select: { status: true } });
      if (!book || book.status !== BookStatus.ACTIVE) throw new HttpError(404, "Libro no disponible en el catálogo.");

      // Descuento atómico de stock: evita que dos usuarios tomen la última copia.
      const updated = await tx.book.updateMany({
        where: { id: bookId, status: BookStatus.ACTIVE, availableCopies: { gt: 0 } },
        data: { availableCopies: { decrement: 1 } },
      });
      if (updated.count === 0) throw new HttpError(409, "No hay copias disponibles en este momento.");

      return tx.loan.create({
        data: { bookId, userId: session.userId, dueDate: addDays(new Date(), LOAN_DAYS) },
        include: loanInclude,
      });
    });

    return NextResponse.json(loan, { status: 201 });
  } catch (error) {
    return handleError(error);
  }
}

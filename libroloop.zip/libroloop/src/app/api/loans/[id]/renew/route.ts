import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { LoanStatus } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { handleError, HttpError } from "@/lib/http";
import { loanInclude, markOverdueLoans } from "@/lib/loans";
import { prisma } from "@/lib/prisma";
import { addDays, MAX_RENEWALS, RENEWAL_DAYS } from "@/lib/rules";
import { isUuid } from "@/lib/utils";

interface RouteContext {
  params: Promise<{ id: string }>;
}

export async function POST(_request: NextRequest, context: RouteContext): Promise<NextResponse> {
  try {
    const session = await requireAuth();
    const { id } = await context.params;
    if (!isUuid(id)) throw new HttpError(404, "Préstamo no encontrado.");

    await markOverdueLoans();

    const loan = await prisma.loan.findUnique({ where: { id } });
    if (!loan || loan.userId !== session.userId) throw new HttpError(404, "Préstamo no encontrado.");
    if (loan.status === LoanStatus.OVERDUE) {
      throw new HttpError(409, "No puedes renovar un préstamo vencido. Devuelve el libro.");
    }
    if (loan.status !== LoanStatus.ACTIVE) throw new HttpError(409, "Solo se pueden renovar préstamos activos.");
    if (loan.renewals >= MAX_RENEWALS) throw new HttpError(409, "Este préstamo ya alcanzó el máximo de renovaciones.");

    // Condición en el WHERE para que dos renovaciones simultáneas no se acumulen.
    const updated = await prisma.loan.updateMany({
      where: { id, status: LoanStatus.ACTIVE, renewals: loan.renewals },
      data: { dueDate: addDays(loan.dueDate, RENEWAL_DAYS), renewals: { increment: 1 } },
    });
    if (updated.count === 0) throw new HttpError(409, "El préstamo cambió. Actualiza e inténtalo de nuevo.");

    const renewed = await prisma.loan.findUnique({ where: { id }, include: loanInclude });
    return NextResponse.json(renewed);
  } catch (error) {
    return handleError(error);
  }
}

import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import type { Role } from "@prisma/client";
import { issueSession } from "@/lib/auth";
import { REFRESH_COOKIE } from "@/lib/constants";
import { clearAuthCookies, setAuthCookies } from "@/lib/cookies";
import { hashToken, safeEqualHex } from "@/lib/crypto";
import { handleError, HttpError } from "@/lib/http";
import { prisma } from "@/lib/prisma";
import { verifyToken } from "@/lib/tokens";
import { safeRedirectPath } from "@/lib/utils";

interface RotatedSession {
  user: { id: string; name: string; email: string; role: Role };
  accessToken: string;
  refreshToken: string;
}

/** Valida el refresh token, detecta reutilización y rota ambos tokens. */
async function rotateSession(request: NextRequest): Promise<RotatedSession> {
  const token = request.cookies.get(REFRESH_COOKIE)?.value;
  if (!token) throw new HttpError(401, "Sesión no encontrada.");

  const claims = await verifyToken(token, "refresh");
  if (!claims) throw new HttpError(401, "Sesión expirada.");

  const user = await prisma.user.findUnique({
    where: { id: claims.userId },
    select: { id: true, name: true, email: true, role: true, refreshTokenHash: true },
  });
  if (!user || !user.refreshTokenHash) throw new HttpError(401, "Sesión inválida.");

  if (!safeEqualHex(user.refreshTokenHash, hashToken(token))) {
    // Token ya rotado o robado: se invalida la sesión completa.
    await prisma.user.update({ where: { id: user.id }, data: { refreshTokenHash: null } });
    throw new HttpError(401, "Sesión inválida.");
  }

  const tokens = await issueSession({ id: user.id, role: user.role });
  return {
    user: { id: user.id, name: user.name, email: user.email, role: user.role },
    ...tokens,
  };
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const session = await rotateSession(request);
    const response = NextResponse.json({ user: session.user });
    setAuthCookies(response, session.accessToken, session.refreshToken);
    return response;
  } catch (error) {
    const response = handleError(error);
    if (response.status === 401) clearAuthCookies(response);
    return response;
  }
}

/** Usado por el middleware: renueva la sesión y redirige a la ruta original. */
export async function GET(request: NextRequest): Promise<NextResponse> {
  const target = safeRedirectPath(request.nextUrl.searchParams.get("redirect"));
  try {
    const session = await rotateSession(request);
    const response = NextResponse.redirect(new URL(target, request.nextUrl.origin));
    setAuthCookies(response, session.accessToken, session.refreshToken);
    return response;
  } catch {
    const loginUrl = new URL("/login", request.nextUrl.origin);
    loginUrl.searchParams.set("next", target);
    const response = NextResponse.redirect(loginUrl);
    clearAuthCookies(response);
    return response;
  }
}

import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { REFRESH_COOKIE } from "@/lib/constants";
import { clearAuthCookies } from "@/lib/cookies";
import { prisma } from "@/lib/prisma";
import { verifyToken } from "@/lib/tokens";

export async function POST(request: NextRequest): Promise<NextResponse> {
  const token = request.cookies.get(REFRESH_COOKIE)?.value;
  if (token) {
    const claims = await verifyToken(token, "refresh");
    if (claims) {
      await prisma.user.updateMany({ where: { id: claims.userId }, data: { refreshTokenHash: null } });
    }
  }
  const response = NextResponse.json({ ok: true });
  clearAuthCookies(response);
  return response;
}

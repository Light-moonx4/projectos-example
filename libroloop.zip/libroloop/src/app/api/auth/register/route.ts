import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import bcrypt from "bcrypt";
import { issueSession } from "@/lib/auth";
import { setAuthCookies } from "@/lib/cookies";
import { handleError, HttpError, readJson } from "@/lib/http";
import { prisma } from "@/lib/prisma";
import { registerSchema } from "@/lib/validators";

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const { name, email, password } = registerSchema.parse(await readJson(request));

    const existing = await prisma.user.findUnique({ where: { email }, select: { id: true } });
    if (existing) throw new HttpError(409, "Ya existe una cuenta con ese correo.");

    const passwordHash = await bcrypt.hash(password, 12);
    const user = await prisma.user.create({
      data: { name, email, passwordHash },
      select: { id: true, name: true, email: true, role: true },
    });

    const tokens = await issueSession(user);
    const response = NextResponse.json({ user }, { status: 201 });
    setAuthCookies(response, tokens.accessToken, tokens.refreshToken);
    return response;
  } catch (error) {
    return handleError(error);
  }
}

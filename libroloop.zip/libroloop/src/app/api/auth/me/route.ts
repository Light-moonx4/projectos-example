import { NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { handleError, HttpError } from "@/lib/http";
import { prisma } from "@/lib/prisma";

export async function GET(): Promise<NextResponse> {
  try {
    const session = await requireAuth();
    const user = await prisma.user.findUnique({
      where: { id: session.userId },
      select: { id: true, name: true, email: true, role: true, createdAt: true },
    });
    if (!user) throw new HttpError(404, "Usuario no encontrado.");
    return NextResponse.json({ user });
  } catch (error) {
    return handleError(error);
  }
}

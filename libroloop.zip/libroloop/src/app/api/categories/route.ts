import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import { handleError, HttpError, readJson } from "@/lib/http";
import { prisma } from "@/lib/prisma";
import { slugify } from "@/lib/utils";
import { categorySchema } from "@/lib/validators";

export async function GET(): Promise<NextResponse> {
  try {
    const items = await prisma.category.findMany({
      orderBy: { name: "asc" },
      select: { id: true, name: true, slug: true, description: true },
    });
    return NextResponse.json({ items });
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    await requireAdmin();
    const { name, description } = categorySchema.parse(await readJson(request));
    const slug = slugify(name);
    if (!slug) throw new HttpError(422, "El nombre no genera un slug válido.");
    const category = await prisma.category.create({
      data: { name, slug, description: description ?? null },
    });
    return NextResponse.json(category, { status: 201 });
  } catch (error) {
    return handleError(error);
  }
}

import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { LoanStatus } from "@prisma/client";
import { requireAdmin } from "@/lib/auth";
import { handleError, HttpError } from "@/lib/http";
import { loanInclude, OPEN_LOAN_STATUSES } from "@/lib/loans";
import { prisma } from "@/lib/prisma";
import { LOST_BOOK_FEE } from "@/lib/rules";
import { isUuid } from "@/lib/utils";

interface RouteContext {
  params: Promise<{ id: string }>;
}

/** Marca el libro como perdido: cobra el cargo fijo y descuenta la copia del inventario. */
export async function POST(_request: NextRequest, context: RouteContext): Promise<NextResponse> {
  try {
    await requireAdmin();
    const { id } = await context.params;
    if (!isUuid(id)) throw new HttpError(404, "Préstamo no encontrado.");

    const result = await prisma.$transaction(async (tx) => {
      const loan = await tx.loan.findUnique({ where: { id } });
      if (!loan) throw new HttpError(404, "Préstamo no encontrado.");
      if (!OPEN_LOAN_STATUSES.includes(loan.status)) {
        throw new HttpError(409, "Solo se pueden marcar como perdidos los préstamos abiertos.");
      }

      const updated = await tx.loan.updateMany({
        where: { id, status: { in: OPEN_LOAN_STATUSES } },
        data: { status: LoanStatus.LOST, fineAmount: LOST_BOOK_FEE },
      });
      if (updated.count === 0) throw new HttpError(409, "El préstamo ya fue cerrado.");

      // La copia nunca regresó: sale del inventario total (disponibles ya se había descontado).
      await tx.book.update({ where: { id: loan.bookId }, data: { totalCopies: { decrement: 1 } } });
      return tx.loan.findUnique({ where: { id }, include: loanInclude });
    });

    return NextResponse.json(result);
  } catch (error) {
    return handleError(error);
  }
}

import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import { handleError } from "@/lib/http";
import { loanInclude, markOverdueLoans } from "@/lib/loans";
import { prisma } from "@/lib/prisma";
import { listLoansQuerySchema } from "@/lib/validators";

export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    await requireAdmin();
    const query = listLoansQuerySchema.parse(Object.fromEntries(request.nextUrl.searchParams));
    await markOverdueLoans();

    const where = query.status ? { status: query.status } : {};
    const [items, total] = await prisma.$transaction([
      prisma.loan.findMany({
        where,
        include: loanInclude,
        orderBy: { loanedAt: "desc" },
        skip: (query.page - 1) * query.pageSize,
        take: query.pageSize,
      }),
      prisma.loan.count({ where }),
    ]);

    return NextResponse.json({ items, total, page: query.page, pageSize: query.pageSize });
  } catch (error) {
    return handleError(error);
  }
}

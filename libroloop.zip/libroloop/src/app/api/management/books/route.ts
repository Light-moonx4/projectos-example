import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import type { Prisma } from "@prisma/client";
import { requireAdmin } from "@/lib/auth";
import { handleError } from "@/lib/http";
import { bookInclude } from "@/lib/loans";
import { prisma } from "@/lib/prisma";
import { listBooksQuerySchema } from "@/lib/validators";

export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    await requireAdmin();
    const query = listBooksQuerySchema.parse(Object.fromEntries(request.nextUrl.searchParams));
    const where: Prisma.BookWhereInput = query.status ? { status: query.status } : {};

    const [items, total] = await prisma.$transaction([
      prisma.book.findMany({
        where,
        include: bookInclude,
        orderBy: { createdAt: "desc" },
        skip: (query.page - 1) * query.pageSize,
        take: query.pageSize,
      }),
      prisma.book.count({ where }),
    ]);

    return NextResponse.json({ items, total, page: query.page, pageSize: query.pageSize });
  } catch (error) {
    return handleError(error);
  }
}

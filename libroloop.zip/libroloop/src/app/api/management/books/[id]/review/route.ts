import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { BookStatus } from "@prisma/client";
import { requireAdmin } from "@/lib/auth";
import { handleError, HttpError, readJson } from "@/lib/http";
import { OPEN_LOAN_STATUSES } from "@/lib/loans";
import { prisma } from "@/lib/prisma";
import { isUuid } from "@/lib/utils";
import { reviewBookSchema } from "@/lib/validators";

interface RouteContext {
  params: Promise<{ id: string }>;
}

/**
 * APPROVE: PENDING -> ACTIVE
 * REJECT:  PENDING -> REJECTED (nota obligatoria)
 * RETIRE:  ACTIVE  -> RETIRED  (nota obligatoria, sin préstamos abiertos)
 */
export async function POST(request: NextRequest, context: RouteContext): Promise<NextResponse> {
  try {
    await requireAdmin();
    const { id } = await context.params;
    if (!isUuid(id)) throw new HttpError(404, "Libro no encontrado.");

    const { decision, note } = reviewBookSchema.parse(await readJson(request));

    const book = await prisma.book.findUnique({ where: { id }, select: { status: true } });
    if (!book) throw new HttpError(404, "Libro no encontrado.");

    if (decision === "APPROVE" || decision === "REJECT") {
      if (book.status !== BookStatus.PENDING) {
        throw new HttpError(409, "Solo se pueden revisar libros en estado pendiente.");
      }
      const updated = await prisma.book.updateMany({
        where: { id, status: BookStatus.PENDING },
        data:
          decision === "APPROVE"
            ? { status: BookStatus.ACTIVE, moderationNote: null }
            : { status: BookStatus.REJECTED, moderationNote: note ?? null },
      });
      if (updated.count === 0) throw new HttpError(409, "El libro ya fue revisado.");
    } else {
      if (book.status !== BookStatus.ACTIVE) throw new HttpError(409, "Solo se pueden retirar libros activos.");
      const openLoans = await prisma.loan.count({
        where: { bookId: id, status: { in: OPEN_LOAN_STATUSES } },
      });
      if (openLoans > 0) {
        throw new HttpError(409, "No se puede retirar el libro: tiene préstamos abiertos.");
      }
      await prisma.book.update({ where: { id }, data: { status: BookStatus.RETIRED, moderationNote: note ?? null } });
    }

    const result = await prisma.book.findUnique({ where: { id }, select: { id: true, status: true } });
    return NextResponse.json({ ok: true, book: result });
  } catch (error) {
    return handleError(error);
  }
}

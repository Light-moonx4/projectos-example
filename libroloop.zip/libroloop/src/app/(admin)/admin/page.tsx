"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { BookStatusBadge, LoanStatusBadge } from "@/components/badges";
import { extractError } from "@/lib/client";
import { formatDate, formatMoney } from "@/lib/utils";
import type { BookDTO, BookStatus, LoanDTO, LoanStatus, Paginated } from "@/types";

type Tab = "books" | "loans";
type Decision = "APPROVE" | "REJECT" | "RETIRE";

const BOOK_FILTERS: { value: BookStatus | "ALL"; label: string }[] = [
  { value: "PENDING", label: "Pendientes" },
  { value: "ACTIVE", label: "Activos" },
  { value: "REJECTED", label: "Rechazados" },
  { value: "RETIRED", label: "Retirados" },
  { value: "ALL", label: "Todos" },
];

const LOAN_FILTERS: { value: LoanStatus | "ALL"; label: string }[] = [
  { value: "OVERDUE", label: "Vencidos" },
  { value: "ACTIVE", label: "En préstamo" },
  { value: "RETURNED", label: "Devueltos" },
  { value: "LOST", label: "Perdidos" },
  { value: "ALL", label: "Todos" },
];

export default function AdminPage() {
  const [tab, setTab] = useState<Tab>("books");
  const [bookFilter, setBookFilter] = useState<BookStatus | "ALL">("PENDING");
  const [loanFilter, setLoanFilter] = useState<LoanStatus | "ALL">("OVERDUE");
  const [books, setBooks] = useState<BookDTO[]>([]);
  const [loans, setLoans] = useState<LoanDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      if (tab === "books") {
        const query = bookFilter === "ALL" ? "?pageSize=50" : `?status=${bookFilter}&pageSize=50`;
        const response = await fetch(`/api/management/books${query}`);
        if (!response.ok) throw new Error(await extractError(response));
        setBooks(((await response.json()) as Paginated<BookDTO>).items);
      } else {
        const query = loanFilter === "ALL" ? "?pageSize=50" : `?status=${loanFilter}&pageSize=50`;
        const response = await fetch(`/api/management/loans${query}`);
        if (!response.ok) throw new Error(await extractError(response));
        setLoans(((await response.json()) as Paginated<LoanDTO>).items);
      }
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "No se pudo cargar la información.");
    } finally {
      setLoading(false);
    }
  }, [tab, bookFilter, loanFilter]);

  useEffect(() => {
    void load();
  }, [load]);

  async function post(url: string, body?: unknown) {
    setError(null);
    try {
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: body === undefined ? undefined : JSON.stringify(body),
      });
      if (!response.ok) throw new Error(await extractError(response));
      await load();
    } catch (actionError) {
      setError(actionError instanceof Error ? actionError.message : "No se pudo completar la acción.");
    }
  }

  async function reviewBook(id: string, decision: Decision) {
    let note: string | undefined;
    if (decision !== "APPROVE") {
      const answer = window.prompt("Nota de moderación (mínimo 10 caracteres):");
      if (answer === null) return;
      note = answer;
    }
    await post(`/api/management/books/${id}/review`, { decision, note });
  }

  async function markLost(id: string) {
    if (!window.confirm("¿Marcar este libro como perdido? Se cobrará el cargo fijo.")) return;
    await post(`/api/management/loans/${id}/lost`);
  }

  const pill = (active: boolean) =>
    `rounded-full border px-3 py-1 text-sm ${active ? "border-slate-900 bg-slate-900 text-white" : "border-slate-300 bg-white"}`;
  const th = "px-4 py-3";
  const td = "px-4 py-3";

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Gestión de la biblioteca</h1>

      <div className="flex gap-2 border-b border-slate-300 pb-2">
        <button type="button" onClick={() => setTab("books")} className={pill(tab === "books")}>
          Libros y donaciones
        </button>
        <button type="button" onClick={() => setTab("loans")} className={pill(tab === "loans")}>
          Préstamos
        </button>
      </div>

      <div className="flex flex-wrap gap-2">
        {tab === "books"
          ? BOOK_FILTERS.map((item) => (
              <button key={item.value} type="button" onClick={() => setBookFilter(item.value)} className={pill(bookFilter === item.value)}>
                {item.label}
              </button>
            ))
          : LOAN_FILTERS.map((item) => (
              <button key={item.value} type="button" onClick={() => setLoanFilter(item.value)} className={pill(loanFilter === item.value)}>
                {item.label}
              </button>
            ))}
      </div>

      {error && <p className="text-sm text-red-600">{error}</p>}
      {loading && <p className="text-slate-500">Cargando...</p>}

      {!loading && tab === "books" && (
        <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-slate-500">
              <tr>
                <th className={th}>Libro</th>
                <th className={th}>Donante</th>
                <th className={th}>Copias</th>
                <th className={th}>Estado</th>
                <th className={th} />
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {books.map((book) => (
                <tr key={book.id}>
                  <td className={td}>
                    <Link href={`/books/${book.id}`} className="font-medium text-indigo-600 hover:underline">
                      {book.title}
                    </Link>
                    <p className="text-xs text-slate-500">{book.author}</p>
                  </td>
                  <td className={td}>{book.donor.name}</td>
                  <td className={td}>
                    {book.availableCopies}/{book.totalCopies}
                  </td>
                  <td className={td}>
                    <BookStatusBadge status={book.status} />
                  </td>
                  <td className={`${td} space-x-2 text-right`}>
                    {book.status === "PENDING" && (
                      <>
                        <button type="button" onClick={() => void reviewBook(book.id, "APPROVE")} className="rounded-md border border-emerald-300 px-3 py-1 text-emerald-700 hover:bg-emerald-50">
                          Aprobar
                        </button>
                        <button type="button" onClick={() => void reviewBook(book.id, "REJECT")} className="rounded-md border border-red-300 px-3 py-1 text-red-600 hover:bg-red-50">
                          Rechazar
                        </button>
                      </>
                    )}
                    {book.status === "ACTIVE" && (
                      <button type="button" onClick={() => void reviewBook(book.id, "RETIRE")} className="rounded-md border border-slate-300 px-3 py-1 hover:bg-slate-50">
                        Retirar
                      </button>
                    )}
                  </td>
                </tr>
              ))}
              {books.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-4 py-8 text-center text-slate-500">
                    No hay libros para este filtro.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {!loading && tab === "loans" && (
        <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-slate-500">
              <tr>
                <th className={th}>Libro</th>
                <th className={th}>Lector</th>
                <th className={th}>Vence</th>
                <th className={th}>Multa</th>
                <th className={th}>Estado</th>
                <th className={th} />
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loans.map((loan) => (
                <tr key={loan.id}>
                  <td className={`${td} font-medium`}>{loan.book.title}</td>
                  <td className={td}>
                    {loan.user.name}
                    <p className="text-xs text-slate-500">{loan.user.email}</p>
                  </td>
                  <td className={td}>{formatDate(loan.dueDate)}</td>
                  <td className={td}>{formatMoney(loan.fineAmount)}</td>
                  <td className={td}>
                    <LoanStatusBadge status={loan.status} />
                  </td>
                  <td className={`${td} space-x-2 text-right`}>
                    {(loan.status === "ACTIVE" || loan.status === "OVERDUE") && (
                      <>
                        <button type="button" onClick={() => void post(`/api/management/loans/${loan.id}/return`)} className="rounded-md border border-emerald-300 px-3 py-1 text-emerald-700 hover:bg-emerald-50">
                          Registrar devolución
                        </button>
                        <button type="button" onClick={() => void markLost(loan.id)} className="rounded-md border border-red-300 px-3 py-1 text-red-600 hover:bg-red-50">
                          Perdido
                        </button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
              {loans.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center text-slate-500">
                    No hay préstamos para este filtro.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

import Link from "next/link";

export default function NotFound() {
  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col items-center justify-center gap-4 px-4 text-center">
      <h1 className="text-5xl font-bold text-indigo-600">404</h1>
      <p className="text-slate-600">No encontramos lo que buscas.</p>
      <Link href="/" className="rounded-md bg-indigo-600 px-4 py-2 text-white hover:bg-indigo-700">
        Volver al inicio
      </Link>
    </main>
  );
}

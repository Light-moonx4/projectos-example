"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState, type FormEvent } from "react";
import { extractError } from "@/lib/client";
import type { CategoryDTO } from "@/types";

export default function DonateBookPage() {
  const router = useRouter();
  const [categories, setCategories] = useState<CategoryDTO[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let cancelled = false;
    async function loadCategories() {
      try {
        const response = await fetch("/api/categories");
        if (!response.ok) throw new Error(await extractError(response));
        const data = (await response.json()) as { items: CategoryDTO[] };
        if (!cancelled) setCategories(data.items);
      } catch (loadError) {
        if (!cancelled) {
          setError(loadError instanceof Error ? loadError.message : "No se pudieron cargar las categorías.");
        }
      }
    }
    void loadCategories();
    return () => {
      cancelled = true;
    };
  }, []);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setError(null);

    const form = new FormData(event.currentTarget);
    const payload = {
      title: String(form.get("title") ?? ""),
      author: String(form.get("author") ?? ""),
      isbn: String(form.get("isbn") ?? ""),
      description: String(form.get("description") ?? ""),
      coverUrl: String(form.get("coverUrl") ?? ""),
      categoryId: String(form.get("categoryId") ?? ""),
      totalCopies: Number(form.get("totalCopies")),
    };

    try {
      const response = await fetch("/api/books", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        setError(await extractError(response));
        return;
      }
      router.push("/dashboard");
      router.refresh();
    } catch {
      setError("No se pudo conectar con el servidor.");
    } finally {
      setLoading(false);
    }
  }

  const inputClass = "w-full rounded-md border border-slate-300 px-3 py-2";
  const labelClass = "mb-1 block text-sm font-medium";

  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="mb-2 text-2xl font-bold">Donar un libro</h1>
      <p className="mb-6 text-sm text-slate-500">
        Tu donación quedará pendiente hasta que el equipo de gestión la revise.
      </p>
      <form onSubmit={handleSubmit} className="space-y-4 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="title" className={labelClass}>Título</label>
            <input id="title" name="title" required minLength={2} maxLength={160} className={inputClass} />
          </div>
          <div>
            <label htmlFor="author" className={labelClass}>Autor</label>
            <input id="author" name="author" required minLength={2} maxLength={120} className={inputClass} />
          </div>
        </div>
        <div>
          <label htmlFor="isbn" className={labelClass}>ISBN (opcional)</label>
          <input id="isbn" name="isbn" className={inputClass} />
        </div>
        <div>
          <label htmlFor="description" className={labelClass}>Descripción</label>
          <textarea id="description" name="description" required minLength={10} maxLength={2000} rows={4} className={inputClass} />
        </div>
        <div>
          <label htmlFor="coverUrl" className={labelClass}>URL de la portada</label>
          <input id="coverUrl" name="coverUrl" type="url" required className={inputClass} />
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="categoryId" className={labelClass}>Categoría</label>
            <select id="categoryId" name="categoryId" required defaultValue="" className={inputClass}>
              <option value="" disabled>Selecciona una categoría</option>
              {categories.map((category) => (
                <option key={category.id} value={category.id}>{category.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="totalCopies" className={labelClass}>Copias a donar</label>
            <input id="totalCopies" name="totalCopies" type="number" min={1} max={5} defaultValue={1} required className={inputClass} />
          </div>
        </div>
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          className="w-full rounded-md bg-indigo-600 px-4 py-2 font-medium text-white hover:bg-indigo-700 disabled:opacity-50"
        >
          {loading ? "Enviando..." : "Enviar donación"}
        </button>
      </form>
    </div>
  );
}

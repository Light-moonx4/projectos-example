import type { ReactNode } from "react";
import { PrivateNav } from "@/components/private-nav";

export default function PrivateLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen">
      <PrivateNav />
      <main className="mx-auto max-w-6xl px-4 py-8">{children}</main>
    </div>
  );
}

"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { BookStatusBadge, LoanStatusBadge } from "@/components/badges";
import { extractError } from "@/lib/client";
import { formatDate, formatMoney } from "@/lib/utils";
import type { BookDTO, LoanDTO, Paginated } from "@/types";

const MAX_RENEWALS = 1;

type DashboardState =
  | { status: "loading" }
  | { status: "error"; message: string }
  | { status: "ready"; loans: LoanDTO[]; donations: BookDTO[] };

export default function DashboardPage() {
  const [state, setState] = useState<DashboardState>({ status: "loading" });
  const [actionError, setActionError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const [loansResponse, donationsResponse] = await Promise.all([
        fetch("/api/loans?pageSize=50"),
        fetch("/api/books?scope=mine&pageSize=50"),
      ]);
      if (!loansResponse.ok) throw new Error(await extractError(loansResponse));
      if (!donationsResponse.ok) throw new Error(await extractError(donationsResponse));

      const loans = (await loansResponse.json()) as Paginated<LoanDTO>;
      const donations = (await donationsResponse.json()) as Paginated<BookDTO>;
      setState({ status: "ready", loans: loans.items, donations: donations.items });
    } catch (error) {
      setState({
        status: "error",
        message: error instanceof Error ? error.message : "No se pudo cargar tu panel.",
      });
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function handleRenew(loanId: string) {
    setActionError(null);
    try {
      const response = await fetch(`/api/loans/${loanId}/renew`, { method: "POST" });
      if (!response.ok) throw new Error(await extractError(response));
      await load();
    } catch (error) {
      setActionError(error instanceof Error ? error.message : "No se pudo renovar el préstamo.");
    }
  }

  if (state.status === "loading") return <p className="text-slate-500">Cargando tu panel...</p>;
  if (state.status === "error") return <p className="text-red-600">{state.message}</p>;

  const openLoans = state.loans.filter((loan) => loan.status === "ACTIVE" || loan.status === "OVERDUE");
  const history = state.loans.filter((loan) => loan.status === "RETURNED" || loan.status === "LOST");

  return (
    <div className="space-y-10">
      <section className="space-y-4">
        <h1 className="text-2xl font-bold">Mis préstamos</h1>
        {actionError && <p className="text-sm text-red-600">{actionError}</p>}
        {openLoans.length === 0 ? (
          <p className="text-sm text-slate-500">
            No tienes préstamos abiertos.{" "}
            <Link href="/books" className="text-indigo-600 underline">
              Explora el catálogo
            </Link>
            .
          </p>
        ) : (
          <ul className="space-y-3">
            {openLoans.map((loan) => (
              <li
                key={loan.id}
                className="flex flex-col gap-3 rounded-xl border border-slate-200 bg-white p-4 sm:flex-row sm:items-center sm:justify-between"
              >
                <div>
                  <Link href={`/books/${loan.book.id}`} className="font-semibold hover:text-indigo-600">
                    {loan.book.title}
                  </Link>
                  <p className="text-sm text-slate-500">{loan.book.author}</p>
                  <p className="mt-1 text-sm">
                    Devolver antes del <strong>{formatDate(loan.dueDate)}</strong>
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <LoanStatusBadge status={loan.status} />
                  {loan.status === "ACTIVE" && loan.renewals < MAX_RENEWALS && (
                    <button
                      type="button"
                      onClick={() => void handleRenew(loan.id)}
                      className="rounded-md border border-indigo-300 px-3 py-1 text-sm text-indigo-700 hover:bg-indigo-50"
                    >
                      Renovar
                    </button>
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="space-y-4">
        <h2 className="text-2xl font-bold">Historial</h2>
        {history.length === 0 ? (
          <p className="text-sm text-slate-500">Todavía no has devuelto libros.</p>
        ) : (
          <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-500">
                <tr>
                  <th className="px-4 py-3">Libro</th>
                  <th className="px-4 py-3">Prestado</th>
                  <th className="px-4 py-3">Devuelto</th>
                  <th className="px-4 py-3">Multa</th>
                  <th className="px-4 py-3">Estado</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {history.map((loan) => (
                  <tr key={loan.id}>
                    <td className="px-4 py-3">{loan.book.title}</td>
                    <td className="px-4 py-3">{formatDate(loan.loanedAt)}</td>
                    <td className="px-4 py-3">{loan.returnedAt ? formatDate(loan.returnedAt) : "—"}</td>
                    <td className="px-4 py-3">{formatMoney(loan.fineAmount)}</td>
                    <td className="px-4 py-3">
                      <LoanStatusBadge status={loan.status} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold">Mis donaciones</h2>
          <Link href="/donate" className="rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700">
            Donar libro
          </Link>
        </div>
        {state.donations.length === 0 ? (
          <p className="text-sm text-slate-500">Aún no has donado libros.</p>
        ) : (
          <ul className="divide-y divide-slate-200 rounded-xl border border-slate-200 bg-white">
            {state.donations.map((book) => (
              <li key={book.id} className="flex items-center justify-between gap-3 px-4 py-3 text-sm">
                <div>
                  <p className="font-medium">{book.title}</p>
                  {book.moderationNote && <p className="text-xs text-slate-500">{book.moderationNote}</p>}
                </div>
                <BookStatusBadge status={book.status} />
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

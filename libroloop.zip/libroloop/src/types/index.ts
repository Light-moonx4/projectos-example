export type Role = "USER" | "ADMIN";

export type BookStatus = "PENDING" | "ACTIVE" | "REJECTED" | "RETIRED";

export type LoanStatus = "ACTIVE" | "RETURNED" | "OVERDUE" | "LOST";

export interface ApiError {
  error: string;
  fields?: Record<string, string[] | undefined>;
}

export interface CategoryDTO {
  id: string;
  name: string;
  slug: string;
  description: string | null;
}

export interface BookDTO {
  id: string;
  title: string;
  author: string;
  isbn: string | null;
  description: string;
  coverUrl: string;
  totalCopies: number;
  availableCopies: number;
  status: BookStatus;
  moderationNote: string | null;
  createdAt: string;
  category: { id: string; name: string; slug: string };
  donor: { id: string; name: string };
}

export interface LoanDTO {
  id: string;
  loanedAt: string;
  dueDate: string;
  returnedAt: string | null;
  renewals: number;
  status: LoanStatus;
  fineAmount: string;
  book: { id: string; title: string; author: string; coverUrl: string };
  user: { id: string; name: string; email: string };
}

export interface Paginated<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
}

export interface AuthUserDTO {
  id: string;
  name: string;
  email: string;
  role: Role;
}

# LibroLoop

Biblioteca comunitaria de préstamos de libros. Next.js 16 (App Router) · TypeScript estricto · Prisma 6 · PostgreSQL (Supabase) · Tailwind 4 · JWT con `jose`.

## Puesta en marcha

```bash
npm install
cp .env.example .env        # completa DATABASE_URL, DIRECT_URL y los secretos JWT
npx prisma migrate dev --name init
npm run db:seed
npm run dev
```

Admin del seed: `admin@libroloop.com` / `Admin123!` (configurable con `SEED_ADMIN_PASSWORD`).
Usuarios demo: `marta@libroloop.com`, `ana@libroloop.com`, `carlos@libroloop.com` / `User12345!`.
(`carlos` tiene un préstamo vencido: no podrá pedir libros hasta devolverlo.)

## Reglas de negocio (`src/lib/rules.ts`)

- Préstamo de 14 días; una renovación de 7 días (solo si no está vencido).
- Máximo 3 préstamos abiertos por usuario; no se puede pedir otro si hay uno vencido ni repetir el mismo libro.
- Stock por copias: el descuento es atómico (`availableCopies > 0`) para evitar sobre-préstamo.
- Multa por atraso: 0.50 por día (se calcula al registrar la devolución). Libro perdido: cargo fijo de 20.00 y la copia sale del inventario.
- Donaciones: un usuario dona (PENDING); gestión aprueba, rechaza o retira. Un admin publica directo (ACTIVE).
- Los préstamos vencidos se marcan de forma perezosa (`markOverdueLoans`); en producción conviene un cron.

## Rutas

| Grupo | URL | Render |
|---|---|---|
| (public) | `/` | SSG |
| (public) | `/books`, `/books/[id]` | SSR |
| (auth) | `/login`, `/register` | - |
| (private) | `/dashboard` (CSR), `/donate` | protegidas |
| (admin) | `/admin` | solo ADMIN |

## API

- `POST /api/auth/register | login | logout | refresh`, `GET /api/auth/me`
- `GET|POST /api/books`, `GET /api/books/[id]`
- `GET|POST /api/loans`, `POST /api/loans/[id]/renew`
- `GET|POST /api/categories`, `DELETE /api/categories/[id]`
- `GET /api/management/books`, `POST /api/management/books/[id]/review`
- `GET /api/management/loans`, `POST /api/management/loans/[id]/return | lost`

## Notas

- `src/middleware.ts` lee las cookies HttpOnly. En Next.js 16 sigue funcionando, pero la convención nueva es `proxy.ts` (renombra el archivo y la función exportada a `proxy`).
- Los refresh tokens se guardan hasheados con SHA-256 (bcrypt trunca a 72 bytes y un JWT lo supera).
